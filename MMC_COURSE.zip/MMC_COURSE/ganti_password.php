<?php
session_start();
require 'koneksi.php'; // Pastikan file koneksi.php ada dan benar

// Redirect jika user belum login
if (!isset($_SESSION['user']['email'])) {
    header("Location: login2.php"); // Ganti ke login2.php jika itu halaman login Anda
    exit();
}

$email = $_SESSION['user']['email'];
$pesan = '';
$pesan_tipe = ''; // 'success' atau 'danger'

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = mysqli_real_escape_string($conn, $_POST['old_password']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Ambil data user dari database untuk memverifikasi password lama
    $query = mysqli_query($conn, "SELECT password FROM register WHERE email='$email'");
    $user = mysqli_fetch_assoc($query);

    if ($user && password_verify($old_password, $user['password'])) {
        if ($new_password === $confirm_password) {
            // Validasi kekuatan password baru (opsional, bisa ditambahkan)
            if (strlen($new_password) < 6) { // Contoh: minimal 6 karakter
                $pesan = "Password baru minimal 6 karakter.";
                $pesan_tipe = 'danger';
            } else {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                mysqli_query($conn, "UPDATE register SET password='$hashed' WHERE email='$email'");
                $pesan = "Password berhasil diganti.";
                $pesan_tipe = 'success';
            }
        } else {
            $pesan = "Password baru dan konfirmasi tidak cocok.";
            $pesan_tipe = 'danger';
        }
    } else {
        $pesan = "Password lama salah.";
        $pesan_tipe = 'danger';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Ganti Password | MMC COURSE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="mmm.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url('download.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            color: #333;
            min-height: 100vh;
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            padding: 20px; /* Add some padding around the form on small screens */
            box-sizing: border-box; /* Pastikan padding tidak membuat body overflow */
        }

        /* Card Styling (similar to login/register forms) */
        .card {
            background: rgba(255, 255, 255, 0.95); /* Semi-transparent white */
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); /* Stronger, softer shadow */
            padding: 30px; /* Increased padding */
            max-width: 420px; /* Consistent width */
            width: 100%;
            border: none; /* Remove default card border */
        }
        .card-title {
            font-weight: 700;
            color: #0d6efd; /* Consistent blue color */
            font-size: 2rem; /* Larger title */
            margin-bottom: 25px; /* Added margin for title */
            text-align: center;
        }
        .form-label {
            font-weight: 600;
            color: #444;
            margin-bottom: 8px; /* Space between label and input */
            display: block; /* Ensures label takes its own line */
        }
        
        /* Input Group with Icon Specific Styling */
        .input-group-icon {
            position: relative;
            margin-bottom: 20px; /* Space between input fields */
        }
        .input-group-icon i.fas {
            position: absolute;
            left: 15px;
            top: 50%; /* Adjusted for vertical centering relative to parent */
            transform: translateY(-50%);
            color: #888;
            z-index: 2; /* Ensure icon is above input */
        }
        .input-group-icon .form-control {
            width: 100%;
            padding: 12px 45px 12px 45px; /* Padding for left icon and right toggle icon */
            border-radius: 8px;
            border: 1px solid #ced4da;
            font-size: 1rem;
            box-sizing: border-box; /* Crucial: Include padding and border in the element's total width */
            outline: none; /* Remove default outline */
        }
        .input-group-icon .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }
        .input-group-icon .form-control::placeholder {
            color: #aaa; /* Adjust placeholder color */
        }
        
        .toggle-password {
            position: absolute;
            top: 50%; /* Adjusted for vertical centering relative to parent */
            right: 15px;
            transform: translateY(-50%);
            cursor: pointer;
            z-index: 3; /* Ensure toggle icon is above input */
            color: #888;
            font-size: 0.95rem; /* Slightly smaller for toggle icon */
        }
        /* End Input Group with Icon Styling */

        .btn-primary {
            background-color: #0d6efd; /* Primary blue button */
            border-color: #0d6efd;
            font-weight: 600;
            padding: 12px; /* Consistent padding */
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%; /* Make button full width */
            font-size: 1.1rem; /* Slightly larger button text */
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0b5ed7;
            transform: translateY(-2px);
        }

        .alert {
            border-radius: 8px;
            font-weight: 500;
            padding: 12px 20px;
            margin-top: 20px;
            text-align: center;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #badbcc;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }

        .text-link {
            color: #0d6efd;
            text-decoration: none;
            transition: color 0.3s ease;
            display: block; /* Ensures link takes its own line */
            margin-top: 20px; /* Space above the link */
            text-align: center;
            font-size: 0.95rem; /* Consistent font size */
        }
        .text-link:hover {
            color: #0b5ed7;
        }

        @media (max-width: 767.98px) {
            .card-title {
                font-size: 1.8rem;
            }
            .card {
                padding: 20px;
                margin: 20px auto; /* Adjust margin for mobile */
            }
        }
    </style>
</head>
<body>

    <div class="card">
        <h4 class="card-title">Ganti Password</h4>

        <form method="POST">
            <div class="mb-3"> <label for="old_password" class="form-label">Password Lama</label>
                <div class="input-group-icon">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="old_password" id="old_password" class="form-control" placeholder="Masukkan password lama" required>
                    <span toggle="#old_password" class="fas fa-eye toggle-password"></span>
                </div>
            </div>

            <div class="mb-3">
                <label for="new_password" class="form-label">Password Baru</label>
                <div class="input-group-icon">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="new_password" id="new_password" class="form-control" placeholder="Masukkan password baru" required>
                    <span toggle="#new_password" class="fas fa-eye toggle-password"></span>
                </div>
            </div>

            <div class="mb-4"> <label for="confirm_password" class="form-label">Konfirmasi Password Baru</label>
                <div class="input-group-icon">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Konfirmasi password baru" required>
                    <span toggle="#confirm_password" class="fas fa-eye toggle-password"></span>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100">Ganti Password</button>
        </form>

        <?php if ($pesan): ?>
            <div class="alert alert-<?= $pesan_tipe ?> text-center mt-3" role="alert"><?= htmlspecialchars($pesan) ?></div>
        <?php endif; ?>

        <div class="text-center mt-3">
            <a href="index1.php" class="text-decoration-none text-link">&larr; Kembali ke Beranda</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(toggle => {
            toggle.addEventListener('click', function () {
                const targetId = this.getAttribute('toggle');
                const passwordInput = document.querySelector(targetId);
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                // Toggle the eye icon
                this.classList.toggle('fa-eye-slash');
            });
        });
    </script>
</body>
</html>