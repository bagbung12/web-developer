<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'koneksi.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login2.php');
    exit();
}

// Ambil data dari tabel register dan tampilkan
// BAGIAN INI TIDAK DIUBAH DARI KODE ASLI ANDA
$query = mysqli_query($conn, "SELECT * FROM register WHERE role = 'user' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Arsip Data Pendaftar - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="mmm.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #212529;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .card {
            border-radius: 0.75rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.08);
            border: none;
        }

        .card-header {
            border-top-left-radius: 0.75rem;
            border-top-right-radius: 0.75rem;
            padding: 1rem 1.5rem;
            background-color: #0d6efd;
            color: white;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header h5 {
            margin: 0;
            font-size: 1.25rem;
        }

        .card-header .btn {
            padding: 0.4rem 1rem;
            font-size: 0.85rem;
            border-radius: 0.5rem;
            transition: all 0.2s ease-in-out;
        }

        .card-header .btn:hover {
            opacity: 0.8;
            transform: translateY(-1px);
        }

        .gap-2 {
            gap: 0.75rem !important;
        }

        .form-control, .form-select {
            border-radius: 0.5rem;
            border-color: #ced4da;
        }

        .table {
            margin-top: 1rem;
            border-radius: 0.5rem;
            overflow: hidden;
        }

        .table thead th {
            background-color: #e9ecef;
            vertical-align: middle;
            padding: 0.75rem 1rem;
        }

        .table tbody td {
            vertical-align: middle;
            padding: 0.75rem 1rem;
        }

        .badge {
            padding: 0.4em 0.7em;
            font-size: 0.8em;
            border-radius: 0.35rem;
        }

        .btn-sm {
            padding: 0.35rem 0.75rem;
            font-size: 0.8rem;
        }

        .navbar {
            border-radius: 0 0 0.75rem 0.75rem;
            box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, 0.05);
        }

        .container {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }

        .filter-row .col-md-4 .form-control,
        .filter-row .col-md-4 .form-select {
            width: 100%;
        }

        .action-cell {
            display: flex;
            flex-direction: column; /* Stack elements vertically */
            gap: 5px; /* Space between elements */
            min-width: 150px; /* Ensure enough width for buttons */
        }
        .action-cell .form-control-sm {
            margin-bottom: 5px; /* Space below file input if present */
        }
        .action-cell .btn {
            width: 100%; /* Make buttons fill the width */
        }

        /* Style untuk tombol "Kembali ke Dashboard" yang baru */
        .back-to-dashboard-btn-container {
            margin-bottom: 1.5rem; /* Memberi jarak antara tombol dan card */
            text-align: left; /* Sesuaikan jika ingin di tengah/kanan */
        }

        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
            }
            .card-header .d-flex {
                flex-wrap: wrap;
            }
            .filter-row .col-md-4 {
                margin-bottom: 1rem;
            }
            .action-cell {
                min-width: unset; /* Remove min-width on small screens */
            }
            .back-to-dashboard-btn-container {
                text-align: center; /* Tengah di mobile */
            }
        }

        @media print {
            form,
            .btn,
            .form-control,
            .form-select,
            .no-print,
            .no-print * {
                display: none !important;
            }
            .card-header,
            .card-body,
            table {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body class="bg-light text-dark">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">
            <i class="fas fa-archive me-2"></i> Arsip Data Pendaftar - <?= htmlspecialchars($_SESSION['user']['email'] ?? '') ?>
        </span>
        <a href="logout.php" class="btn btn-danger btn-sm"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
    </div>
</nav>

<div class="container">
    <div class="back-to-dashboard-btn-container no-print">
        <a href="dashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i> Kembali ke Dashboard</a>
    </div>

    <div class="card mb-4" id="archive-section">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Daftar Pendaftar yang Diarsipkan</h5>
        </div>

        <div class="card-body">
            <div class="row mb-3 filter-row no-print">
                <div class="col-md-4">
                    <input type="text" id="search-archive" class="form-control" placeholder="Cari Nama / Email...">
                </div>
                <div class="col-md-4">
                    <select id="filter-course" class="form-select">
                        <option value="">Semua Course</option>
                        <?php
                            // Ambil daftar course dari database untuk filter
                            // Data ini diambil sekali saat page load
                            $courses = mysqli_query($conn, "SELECT DISTINCT course FROM register WHERE role = 'user' ORDER BY course ASC");
                            while ($c = mysqli_fetch_assoc($courses)) {
                                echo '<option value="' . htmlspecialchars($c['course']) . '">' . htmlspecialchars($c['course']) . '</option>';
                            }
                        ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="date" id="filter-date" class="form-control">
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Course</th>
                            <th>Tanggal</th>
                            <th>NO_HP</th>
                            <th>TIPE_NO_HP</th>
                            <th class="no-print">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="archive-body">
                        <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                        <tr class="data-row">
                            <td data-fullname="<?= htmlspecialchars(strtolower($row['fullname'])) ?>"><?= htmlspecialchars($row['fullname']) ?></td>
                            <td data-username="<?= htmlspecialchars(strtolower($row['username'])) ?>"><?= htmlspecialchars($row['username']) ?></td>
                            <td data-email="<?= htmlspecialchars(strtolower($row['email'])) ?>"><?= htmlspecialchars($row['email']) ?></td>
                            <td data-course="<?= htmlspecialchars(strtolower($row['course'])) ?>"><?= htmlspecialchars($row['course']) ?></td>
                            <td data-tanggal="<?= htmlspecialchars(date('Y-m-d', strtotime($row['tanggal']))) ?>"><?= htmlspecialchars($row['tanggal']) ?></td>
                            <td><?= !empty($row['no_hp']) ? htmlspecialchars($row['no_hp']) : '<span class="text-danger">Kosong</span>' ?></td>
                            <td><?= isset($row['tipe_no_hp']) ? htmlspecialchars($row['tipe_no_hp']) : '<span class="text-danger">Tidak Ada</span>' ?></td>
                            <td class="no-print action-cell">
                                <form action="upload_file.php" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <label class="form-label mb-1">Pilih File:</label>
                                    <input type="file" name="file" class="form-control form-control-sm mb-1" required>
                                    <button type="submit" class="btn btn-sm btn-success"><i class="fas fa-upload me-1"></i> Upload File</button>
                                </form>

                                <a href="review.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary"><i class="fas fa-eye me-1"></i> Review</a>

                                <form action="kirim_email.php" method="POST">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-info"><i class="fas fa-envelope me-1"></i> Kirim File via Email</button>
                                </form>
                                <form action="hapus_arsip.php" method="POST" onsubmit="return confirm('Yakin ingin menghapus data arsip ini? Ini akan menghapus data user dari arsip!');">
                                    <input type="hidden" name="id" value="<?= htmlspecialchars($row['id']) ?>">
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt me-1"></i> Hapus Arsip</button>
                                </form>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div> </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function printSection(id) {
        const originalContent = document.body.innerHTML;
        const printContent = document.getElementById(id).innerHTML;
        document.body.innerHTML = printContent;
        window.print();
        document.body.innerHTML = originalContent;
        location.reload(); // Reload page to restore original content and scripts
    }

    // Client-side Filtering Logic (No Backend PHP change needed)
    const searchInput = document.getElementById("search-archive");
    const filterCourse = document.getElementById("filter-course");
    const filterDate = document.getElementById("filter-date");
    const tableBody = document.getElementById("archive-body");
    const tableRows = tableBody.getElementsByClassName("data-row");

    function applyFilters() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCourse = filterCourse.value.toLowerCase();
        const selectedDate = filterDate.value; // YYYY-MM-DD format

        for (let i = 0; i < tableRows.length; i++) {
            const row = tableRows[i];
            const fullname = row.querySelector('[data-fullname]').dataset.fullname;
            const email = row.querySelector('[data-email]').dataset.email;
            const course = row.querySelector('[data-course]').dataset.course;
            const tanggal = row.querySelector('[data-tanggal]').dataset.tanggal;

            let matchesSearch = true;
            if (searchTerm) {
                matchesSearch = fullname.includes(searchTerm) || email.includes(searchTerm);
            }

            let matchesCourse = true;
            if (selectedCourse) {
                matchesCourse = course === selectedCourse;
            }

            let matchesDate = true;
            if (selectedDate) {
                matchesDate = tanggal === selectedDate;
            }

            if (matchesSearch && matchesCourse && matchesDate) {
                row.style.display = ""; // Show row
            } else {
                row.style.display = "none"; // Hide row
            }
        }
    }

    searchInput.addEventListener("keyup", applyFilters);
    filterCourse.addEventListener("change", applyFilters);
    filterDate.addEventListener("change", applyFilters);

    // Initial filter application when page loads (to ensure consistency if filters were pre-set, though not in this case)
    applyFilters();

</script>
</body>
</html>