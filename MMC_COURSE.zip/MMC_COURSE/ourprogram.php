<?php
session_start();
require 'koneksi.php'; // Pastikan file koneksi.php ada dan benar

$username = isset($_SESSION['user']['username']) ? htmlspecialchars($_SESSION['user']['username']) : 'PROFIL';
$current_page = basename($_SERVER['PHP_SELF']); // Ini akan menjadi 'ourprogram.php'

$id_user = $_SESSION['user']['id'] ?? 0;
$notif_pesan = '';
$ada_notif = false;


if ($id_user > 0 && isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'user') {
    $cek = mysqli_query($conn, "SELECT notif_sertifikat FROM register WHERE id = $id_user");
    $data = mysqli_fetch_assoc($cek);

    if ($data && $data['notif_sertifikat'] == 1) {
        $notif_pesan = "🎉 Sertifikat kamu telah dikirim ke email.";
        $ada_notif = true;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Our Program | MMC COURSE</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="icon" type="image/png" href="mmm.png">
    
    <style>
        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', sans-serif; /* Menggunakan Poppins */
            background: url(download.jpeg) no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Main content takes remaining space */
        main {
            flex: 1;
            padding-top: 70px; /* Adjust for fixed navbar height */
        }

        /* Navbar Styling (Consistent with other pages) */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030;
            position: fixed; /* Make navbar fixed */
            top: 0;
            width: 100%;
        }
        .navbar-brand img {
            height: 35px; /* Slightly larger */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd;
        }
        .navbar-nav .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
            border: none;
        }
        .navbar-nav .dropdown-item {
            color: #333;
            transition: background-color 0.2s ease;
        }
        .navbar-nav .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #0d6efd;
        }
        /* Notification bell styling */
        .nav-item .fa-bell {
            color: #0d6efd; /* Blue bell icon */
        }
        .nav-item .badge {
            font-size: 0.75em;
            padding: 0.35em 0.6em;
        }

        /* Program Content Section Styling */
        .program-section {
            background-color: rgba(255, 255, 255, 0.95); /* Semi-transparent white background */
            border-radius: 10px;
            padding: 40px;
            margin-top: 40px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .program-section h3 {
            font-weight: 700;
            color: #0d6efd; /* Consistent blue color */
            margin-bottom: 30px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }

        .program-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: transform 0.2s ease;
            display: flex; /* Use flexbox for internal layout */
            flex-direction: column;
        }
        .program-card:hover {
            transform: translateY(-3px);
        }
        .program-card h4 {
            color: #0d6efd;
            font-weight: 600;
            margin-bottom: 15px;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .program-card ul {
            list-style: none;
            padding: 0;
            margin-top: 15px;
            flex-grow: 1; /* Allow ul to grow and fill space */
        }
        .program-card ul li {
            padding: 8px 0; /* Increased padding */
            color: #555;
            font-size: 0.95rem;
            display: flex;
            align-items: flex-start;
            line-height: 1.5; /* Improved line height for readability */
        }
        .program-card ul li::before {
            content: "\f00c"; /* Font Awesome check icon */
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            color: #28a745; /* Green checkmark */
            margin-right: 10px;
            font-size: 0.8rem;
            line-height: inherit; /* Inherit line height for icon alignment */
            padding-top: 2px; /* Small adjustment for better vertical alignment */
        }
        .program-card strong {
            color: #333; /* Darker color for strong text */
        }

        /* Form Jadwal Styling */
        .registration-form {
            background-color: rgba(255, 255, 255, 0.95); /* Semi-transparent white background */
            border-radius: 10px;
            padding: 40px;
            margin-top: 40px;
            margin-bottom: 40px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .registration-form h3 {
            font-weight: 700;
            color: #0d6efd;
            margin-bottom: 30px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }
        .registration-form .form-label {
            font-weight: 600;
            color: #444;
        }
        .registration-form .form-select-lg {
            font-size: 1.1rem;
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
        }
        .registration-form .btn {
            border-radius: 0.5rem;
            font-weight: 600;
            padding: 0.75rem 1.25rem;
            transition: all 0.2s ease;
        }
        .day.active,
        .time-slot.active {
            background-color: #0d6efd !important; /* Bootstrap primary blue */
            color: white !important;
            border-color: #0d6efd !important;
        }
        .time-slot {
            /* Perbaikan utama untuk tombol jam */
            min-width: 140px; /* Increased min-width to accommodate text better */
            padding: 0.5rem 0.75rem; /* Adjusted padding */
            white-space: nowrap; /* Ensures text stays on one line */
            overflow: hidden; /* Hides overflowing text */
            text-overflow: ellipsis; /* Adds ellipsis if text overflows (optional, can remove) */
            display: inline-flex; /* Use flex for centering if needed */
            align-items: center;
            justify-content: center;
        }
        /* Style for the scrollable container of time slots */
        .time-slots-container {
            display: flex;
            gap: 10px; /* Space between buttons */
            overflow-x: auto; /* Enable horizontal scrolling */
            -webkit-overflow-scrolling: touch; /* Smoother scrolling on iOS */
            padding-bottom: 10px; /* Add padding for scrollbar if present */
        }
        .time-slots-container::-webkit-scrollbar {
            height: 8px; /* Height of the scrollbar */
        }
        .time-slots-container::-webkit-scrollbar-thumb {
            background-color: #ced4da; /* Color of the scrollbar thumb */
            border-radius: 10px;
        }
        .time-slots-container::-webkit-scrollbar-track {
            background-color: #f8f9fa; /* Color of the scrollbar track */
        }

        .alert-info {
            background-color: #e0f2f7;
            border-color: #b3e0ed;
            color: #0d6efd;
            white-space: pre-line; /* Preserve line breaks in JS output */
            font-weight: 500;
        }

        /* Footer (Consistent with other pages) */
        footer {
            background: #222;
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: auto;
        }
        footer a {
            color: #FFC107;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }

        /* Media Queries */
        @media (max-width: 767.98px) { /* Small devices (landscape phones, 576px and down) */
            .program-section, .registration-form {
                padding: 25px;
            }
            .program-section h3, .registration-form h3 {
                font-size: 1.8rem;
            }
            .program-card h4 {
                font-size: 1.3rem;
            }
            /* Adjustments for mobile program list items */
            .program-card ul li {
                font-size: 0.9rem;
                padding: 6px 0;
            }
            .program-card ul li::before {
                margin-right: 8px;
            }
        }
        @media (min-width: 768px) { /* Medium devices (tablets, 768px and up) */
            .d-md-block {
                display: block !important;
            }
            .d-md-none {
                display: none !important;
            }
        }
    </style>
</head>
<body>

<div class="container-fluid px-0">

    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                <img src="mmm.png" alt="MMC Logo" class="me-2">
                MMC COURSE
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav gap-2">
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index1.php">HOME</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'blog.php' ? 'active' : '' ?>" href="blog.php">BLOG</a></li>
                    <li class="nav-item"><a class="nav-link <?= ($current_page == 'service.php' || $current_page == 'service1.php') ? 'active' : '' ?>" href="service.php">SERVICE</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'ourprogram.php' ? 'active' : '' ?>" href="ourprogram.php">OUR PROGRAM</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'contact.php' ? 'active' : '' ?>" href="contact.php">CONTACT</a></li>
                    
                    <?php if (isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'user'): ?>
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link position-relative dropdown-toggle" href="#" id="notifDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell"></i>
                                <?php if ($ada_notif): ?>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        1
                                        <span class="visually-hidden">unread messages</span>
                                    </span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notifDropdown">
                                <?php if ($ada_notif): ?>
                                    <li><span class="dropdown-item text-success"><?= $notif_pesan ?></span></li>
                                <?php else: ?>
                                    <li><span class="dropdown-item text-muted">Tidak ada notifikasi baru</span></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item dropdown">
                        <a class="btn btn-outline-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i> <?= $username ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['user'])): // Cek apakah ada sesi user aktif ?>
                                <li><a class="dropdown-item" href="edit_profil.php"><i class="fas fa-edit me-2"></i>Edit Profil</a></li>
                                <li><a class="dropdown-item" href="ganti_password.php"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="login2.php"><i class="fas fa-sign-in-alt me-2"></i>Login</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container my-5">
        <section class="program-section">
            <h3 class="text-center mb-4">Our Programs</h3>

            <div class="d-none d-md-block">
                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <div class="program-card h-100">
                            <h4>English</h4>
                            <ul>
                                <li><strong>English for Children (FFC):</strong> Program ini dirancang untuk anak-anak berusia 6-12 tahun. Di program ini, anak-anak diperkenalkan dengan benda-benda, makanan, buah buahan, jenis-jenis binatang, dll. Struktur dan pola-pola bahasa Inggris dan yang paling dasar dipelajari dalam program ini. Anak-anak akan dibimbing sehingga mampu dan terbiasa untuk berkomunikasi dalam bahasa Inggris dengan baik dan benar.</li>
                                <li><strong>General English:</strong> General English ini dibagi menjadi 9 level, dari Pre Elementary sampai Post Advanced. Program ini dirancang untuk mempersiapkan para siswa dengan dasar yang baik untuk berkomunikasi dalam Bahasa Inggris dengan lancar.</li>
                                <li><strong>Conversation Program:</strong> Conversation Program percakapan ini dibagi menjadi 3 level dan level elementary sampai advance. Dengan program ini kemampuan berkomunikasi para siswa ditingkatkan melalui percakapan, permainan dan simulasi yang dirancang khusus agar para siswa belajar untuk mengekspresikan perasaan dan pendapat mereka secara aktif dan benar.</li>
                                <li>TOEIC, TOEFL, IELTS</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="program-card h-100">
                            <h4>Mandarin</h4>
                            <ul>
                                <li><strong>Chu Ji I–IV:</strong> pelajaran akan lebih ditekankan pada karakter dasar dan pelafalannya. Juga pengenalan huruf-huruf yang sederhana beserta cara penulisan yang benar. Juga diajarkan cara pencairan huruf dalam kamus bahasa Mandarin-Indonesia. Perbandingan antara tulisan dan percakapan adalah 40 dan 60. Pada tingkat dasar III dan IV, pelajaran akan lebih ditekankan pada pola kalimat dasar dan sederhana. Juga mengasah kemampuan untuk pelafalan yang benar. Pada tingkat ini diajarkan menggunakan kamus Mandarin – Mandarin. Perbandingan antara tulisan dan percakapan adalah 50 dan 50</li>
                                <li><strong>Zhong Ji I–II:</strong> Di tingkat menengah ini baik I maupun II, pelajaran akan lebih ditekankan pada percakapan dengan menggunakan pola kalimat yang masih sederhana. Pada tingkat ini sudah mulai menggunakan bahasa Mandarin sebagai pengantar kendati masih sederhana. Pada tingkat ini juga dipelajari huruf-huruf yang lebih banyak dan mendalam. Perbandingan antara tulisan dan percakapan adalah 40 dan 60.</li>
                                <li><strong>Gao Ji I–II:</strong> Pada tingkat lanjutan ini, penekanan berada pada percakapan. Pada tingkat ini juga telah menggunakan pola kalimat yang lebih kompleks dibandingkan tingkat sebelumnya. Pada tingkat ini hampir seluruh pelajarannya adalah pola kalimat dan percakapan. Tulisan dan huruf-huruf masih dipelajari lebih mendalam kendati sudah agak berkurang. Perbandingan antara tulisan dan percakapan adalah 30 dan 70.</li>
                                <li><strong>Shang Ye Hui Hua (Percakapan Dunia Bisnis):</strong> Program ini ditekankan pada percakapan dalam bidang bisnis. Perbandingan antara tulisan dan percakapan adalan 30 dan 70.</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <div class="program-card h-100">
                            <h4>Japanese</h4>
                            <ul>
                                <li><strong>Shokyu I:</strong> mulai dari hiragana dan katakana. Juga akan mempelajari pola-pola kalimat bahasa Jepang dasar.</li>
                                <li><strong>Shokyu II:</strong> Pengetahuan moji ditingkatkan ke pelajaran kanji dasar dan pola-pola kalimat yang dipelajari lebih dalam.</li>
                                <li><strong>Shokyu III:</strong> Dengan semakin mahirnya penguasaan pola-pola kalimat dasar bahasa Jepang, siswa akan dapat berkomunikasi dengan bentuk bahasa Jepang dasar secara umum.</li>
                                <li><strong>Chukyu I,II,III:</strong> Karena siswa telah memiliki dasar bahasa Jepang yang kuat, maka di tingkat menengah ini siswa akan mempelajari bentuk-bentuk penggunaan bahasa Jepang untuk percakapan sehari-hari. Selain itu juga akan diperkenalkan cerita-cerita Jepang yang menarik kerana siswa harus dapat menyimak dan menceritakannya kembali.</li>
                                <li><strong>Kaiwa I,II,III:</strong> Program kaiwa merupakan kelas percakapan untuk melancarkan penguasaan bahasa Jepang sehingga dapat mahir berbicara bahasa Jepang dengan baik dan benar.</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="program-card h-100">
                            <h4>Komputer</h4>
                            <ul>
                                <li><strong>Ms. Word & PowerPoint</strong></li>
                                <li><strong>Database:</strong> Ms. Access</li>
                                <li><strong>Desain:</strong> CorelDRAW, Photoshop</li>
                                <li><strong>MYOB, AutoCAD, Web Design, 3D/2D Animation</strong></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-12">
                        <div class="program-card h-100">
                            <h4>French</h4>
                            <ul>
                                <li><strong>Debutant:</strong> Tingkat pemula (Debutant) terbagi atas tingkat A (Vrai Debutant), B (Debutant I) dan C (Debutant II). Fokus dari ketiga tingkat ini dititikberatkan pada penguasaan dasar bahasa lisan dan tulisan dengan menggunakan pendekatan komunikatif dan tubian (drill).</li>
                                <li><strong>Intermediate:</strong> Tingkat menengah (Intermediate) terbagi atas tingkat D (Intermediate I) dan E (Intermediate 2). Pada kedua tingkat ini peserta kursus dibimbing untuk semakin memperdalam penguasaan dasar bahasa Perancis dengan materi pembelajaran yang semakin menarik.</li>
                                <li><strong>Advance:</strong> Tingkat mahir (Advance) terbagi atas tingkat F (Advance I) dan G (Advance 2) serta tingkat H (Perfectionnement). Pada tingkat ini para peserta kursus telah memiliki kemampuan lisan (Expression Orale) dan tulisan (Expression Ecrite) dasar dan menengah. Fokus pembelajaran pada eksprisi lisan dalam bahasa sasaran.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-md-none">
                <div class="program-card mb-3">
                    <button class="btn btn-link w-100 text-start fw-bold text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEnglish" aria-expanded="false" aria-controls="collapseEnglish">
                        <h4>English <i class="fas fa-chevron-down float-end"></i></h4>
                    </button>
                    <div class="collapse" id="collapseEnglish">
                        <ul>
                            <li><strong>English for Children (FFC):</strong> Program ini dirancang untuk anak-anak berusia 6-12 tahun. Di program ini, anak-anak diperkenalkan dengan benda-benda, makanan, buah buahan, jenis-jenis binatang, dll. Struktur dan pola-pola bahasa Inggris dan yang paling dasar dipelajari dalam program ini. Anak-anak akan dibimbing sehingga mampu dan terbiasa untuk berkomunikasi dalam bahasa Inggris dengan baik dan benar.</li>
                            <li><strong>General English:</strong> General English ini dibagi menjadi 9 level, dari Pre Elementary sampai Post Advanced. Program ini dirancang untuk mempersiapkan para siswa dengan dasar yang baik untuk berkomunikasi dalam Bahasa Inggris dengan lancar.</li>
                            <li><strong>Conversation Program:</strong> Conversation Program percakapan ini dibagi menjadi 3 level dan level elementary sampai advance. Dengan program ini kemampuan berkomunikasi para siswa ditingkatkan melalui percakapan, permainan dan simulasi yang dirancang khusus agar para siswa belajar untuk mengekspresikan perasaan dan pendapat mereka secara aktif dan benar.</li>
                            <li>TOEIC, TOEFL, IELTS</li>
                        </ul>
                    </div>
                </div>

                <div class="program-card mb-3">
                    <button class="btn btn-link w-100 text-start fw-bold text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMandarin" aria-expanded="false" aria-controls="collapseMandarin">
                        <h4>Mandarin <i class="fas fa-chevron-down float-end"></i></h4>
                    </button>
                    <div class="collapse" id="collapseMandarin">
                        <ul>
                            <li><strong>Chu Ji I–IV:</strong> pelajaran akan lebih ditekankan pada karakter dasar dan pelafalannya. Juga pengenalan huruf-huruf yang sederhana beserta cara penulisan yang benar. Juga diajarkan cara pencairan huruf dalam kamus bahasa Mandarin-Indonesia. Perbandingan antara tulisan dan percakapan adalah 40 dan 60. Pada tingkat dasar III dan IV, pelajaran akan lebih ditekankan pada pola kalimat dasar dan sederhana. Juga mengasah kemampuan untuk pelafalan yang benar. Pada tingkat ini diajarkan menggunakan kamus Mandarin – Mandarin. Perbandingan antara tulisan dan percakapan adalah 50 dan 50</li>
                            <li><strong>Zhong Ji I–II:</strong> Di tingkat menengah ini baik I maupun II, pelajaran akan lebih ditekankan pada percakapan dengan menggunakan pola kalimat yang masih sederhana. Pada tingkat ini sudah mulai menggunakan bahasa Mandarin sebagai pengantar kendati masih sederhana. Pada tingkat ini juga dipelajari huruf-huruf yang lebih banyak dan mendalam. Perbandingan antara tulisan dan percakapan adalah 40 dan 60.</li>
                            <li><strong>Gao Ji I–II:</strong> Pada tingkat lanjutan ini, penekanan berada pada percakapan. Pada tingkat ini juga telah menggunakan pola kalimat yang lebih kompleks dibandingkan tingkat sebelumnya. Pada tingkat ini hampir seluruh pelajarannya adalah pola kalimat dan percakapan. Tulisan dan huruf-huruf masih dipelajari lebih mendalam kendati sudah agak berkurang. Perbandingan antara tulisan dan percakapan adalah 30 dan 70.</li>
                            <li><strong>Shang Ye Hui Hua (Percakapan Dunia Bisnis):</strong> Program ini ditekankan pada percakapan dalam bidang bisnis. Perbandingan antara tulisan dan percakapan adalan 30 dan 70.</li>
                        </ul>
                    </div>
                </div>

                <div class="program-card mb-3">
                    <button class="btn btn-link w-100 text-start fw-bold text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseJapanese" aria-expanded="false" aria-controls="collapseJapanese">
                        <h4>Japanese <i class="fas fa-chevron-down float-end"></i></h4>
                    </button>
                    <div class="collapse" id="collapseJapanese">
                        <ul>
                            <li><strong>Shokyu I:</strong> mulai dari hiragana dan katakana. Juga akan mempelajari pola-pola kalimat bahasa Jepang dasar.</li>
                            <li><strong>Shokyu II:</strong> Pengetahuan moji ditingkatkan ke pelajaran kanji dasar dan pola-pola kalimat yang dipelajari lebih dalam.</li>
                            <li><strong>Shokyu III:</strong> Dengan semakin mahirnya penguasaan pola-pola kalimat dasar bahasa Jepang, siswa akan dapat berkomunikasi dengan bentuk bahasa Jepang dasar secara umum.</li>
                            <li><strong>Chukyu I,II,III:</strong> Karena siswa telah memiliki dasar bahasa Jepang yang kuat, maka di tingkat menengah ini siswa akan mempelajari bentuk-bentuk penggunaan bahasa Jepang untuk percakapan sehari-hari. Selain itu juga akan diperkenalkan cerita-cerita Jepang yang menarik kerana siswa harus dapat menyimak dan menceritakannya kembali.</li>
                            <li><strong>Kaiwa I,II,III:</strong> Program kaiwa merupakan kelas percakapan untuk melancarkan penguasaan bahasa Jepang sehingga dapat mahir berbicara bahasa Jepang dengan baik dan benar.</li>
                        </ul>
                    </div>
                </div>

                <div class="program-card mb-3">
                    <button class="btn btn-link w-100 text-start fw-bold text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseComputer" aria-expanded="false" aria-controls="collapseComputer">
                        <h4>Komputer <i class="fas fa-chevron-down float-end"></i></h4>
                    </button>
                    <div class="collapse" id="collapseComputer">
                        <ul>
                            <li><strong>Ms. Word & PowerPoint</strong></li>
                            <li><strong>Database:</strong> Ms. Access</li>
                            <li><strong>Desain:</strong> CorelDRAW, Photoshop</li>
                            <li><strong>MYOB, AutoCAD, Web Design, 3D/2D Animation</strong></li>
                        </ul>
                    </div>
                </div>

                <div class="program-card mb-3">
                    <button class="btn btn-link w-100 text-start fw-bold text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFrench" aria-expanded="false" aria-controls="collapseFrench">
                        <h4>French <i class="fas fa-chevron-down float-end"></i></h4>
                    </button>
                    <div class="collapse" id="collapseFrench">
                        <ul>
                            <li><strong>Debutant:</strong> Tingkat pemula (Debutant) terbagi atas tingkat A (Vrai Debutant), B (Debutant I) dan C (Debutant II). Fokus dari ketiga tingkat ini dititikberatkan pada penguasaan dasar bahasa lisan dan tulisan dengan menggunakan pendekatan komunikatif dan tubian (drill).</li>
                            <li><strong>Intermediate:</strong> Tingkat menengah (Intermediate) terbagi atas tingkat D (Intermediate I) dan E (Intermediate 2). Pada kedua tingkat ini peserta kursus dibimbing untuk semakin memperdalam penguasaan dasar bahasa Perancis dengan materi pembelajaran yang semakin menarik.</li>
                            <li><strong>Advance:</strong> Tingkat mahir (Advance) terbagi atas tingkat F (Advance I) dan G (Advance 2) serta tingkat H (Perfectionnement). Pada tingkat ini para peserta kursus telah memiliki kemampuan lisan (Expression Orale) dan tulisan (Expression Ecrite) dasar dan menengah. Fokus pembelajaran pada eksprisi lisan dalam bahasa sasaran.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section id="ourprogram-form" class="registration-form mt-5">
            <h3 class="text-center mb-4 fw-bold text-primary">Pilih Jadwal Kursus</h3>

            <div class="mb-4">
                <label for="course-select" class="form-label">Jenis Kursus</label>
                <select id="course-select" class="form-select form-select-lg">
                    <option value="">-- Pilih Kursus --</option>
                    <option value="Bahasa Inggris">Bahasa Inggris</option>
                    <option value="Mandarin">Mandarin</option>
                    <option value="Komputer">Komputer</option>
                    <option value="Prancis">Prancis</option>
                    <option value="Jepang">Jepang</option>
                </select>
            </div>

            <div class="mb-4">
                <label class="form-label">Hari</label>
                <div class="row g-2 text-center">
                    <div class="col-6 col-md-3">
                        <button class="btn btn-outline-primary w-100 day" data-day="Senin Rabu">Senin Rabu</button>
                    </div>
                    <div class="col-6 col-md-3">
                        <button class="btn btn-outline-primary w-100 day" data-day="Selasa Kamis">Selasa Kamis</button>
                    </div>
                    <div class="col-6 col-md-3">
                        <button class="btn btn-outline-primary w-100 day" data-day="Rabu Jumat">Rabu Jumat</button>
                    </div>
                    <div class="col-6 col-md-3">
                        <button class="btn btn-outline-primary w-100 day" data-day="Kamis Sabtu">Kamis Sabtu</button>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Jam</label>
                <div class="time-slots-container"> <button class="btn btn-outline-secondary time-slot" data-time="09:00 - 10:30">09:00 - 10:30</button>
                    <button class="btn btn-outline-secondary time-slot" data-time="10:30 - 12:00">10:30 - 12:00</button>
                    <button class="btn btn-outline-secondary time-slot" data-time="12:00 - 13:30">12:00 - 13:30</button>
                    <button class="btn btn-outline-secondary time-slot" data-time="13:30 - 15:00">13:30 - 15:00</button>
                    <button class="btn btn-outline-secondary time-slot" data-time="15:00 - 16:30">15:00 - 16:30</button>
                    <button class="btn btn-outline-secondary time-slot" data-time="16:30 - 18:00">16:30 - 18:00</button>
                    <button class="btn btn-outline-secondary time-slot" data-time="18:00 - 19:30">18:00 - 19:30</button>
                </div>
            </div>

            <div class="d-grid gap-2 mb-3">
                <button class="btn btn-lg btn-success" onclick="redirectToWhatsApp()">📲 Booking Sekarang</button>
                <button class="btn btn-lg btn-outline-danger" onclick="resetSelection()">🔄 Reset Pilihan</button>
            </div>

            <div class="alert alert-info text-center" id="booking-info" style="display:none;"></div>
        </section>
    </main>

    <footer class="text-center">
        <div class="container">
            <p>&copy; <?= date("Y") ?> MMC Course. All rights reserved.</p>
            <p>Ikuti kami:
                <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram ms-2"></i></a>
            </p>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
 
<script>
    // Script for notification bell (consistent with other pages)
    const notifBell = document.getElementById('notifDropdown');

    notifBell?.addEventListener('click', function () {
        const badge = notifBell.querySelector('.badge');
        if (badge) {
            fetch('reset_notif.php')
                .then(response => response.text())
                .then(data => {
                    if (data.trim() === 'ok') {
                        badge.remove();
                        const dropdownMenu = notifBell.nextElementSibling;
                        if (dropdownMenu) {
                            dropdownMenu.innerHTML = '<li><span class="dropdown-item text-muted">Tidak ada notifikasi baru</span></li>';
                        }
                    }
                })
                .catch(error => console.error('Error resetting notification:', error));
        }
    });

    // Script for booking form
    let selectedCourse = "";
    let selectedDay = "";
    let selectedTime = "";

    const courseSelect = document.getElementById("course-select");
    const dayButtons = document.querySelectorAll(".day");
    const timeButtons = document.querySelectorAll(".time-slot");
    const bookingInfo = document.getElementById("booking-info");

    courseSelect.addEventListener("change", () => {
        selectedCourse = courseSelect.value;
        updateBookingInfo();
    });

    dayButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            selectedDay = btn.dataset.day;
            dayButtons.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            updateBookingInfo();
        });
    });

    timeButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            selectedTime = btn.dataset.time;
            timeButtons.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            updateBookingInfo();
        });
    });

    function updateBookingInfo() {
        if (selectedCourse && selectedDay && selectedTime) {
            bookingInfo.textContent = `📚 Kursus: ${selectedCourse}\n📅 Hari: ${selectedDay}\n⏰ Jam: ${selectedTime}`;
            bookingInfo.style.display = "block";
        } else {
            bookingInfo.textContent = "";
            bookingInfo.style.display = "none";
        }
    }

    function redirectToWhatsApp() {
        if (!selectedCourse || !selectedDay || !selectedTime) {
            alert("Silakan pilih kursus, hari dan jam terlebih dahulu!");
            return;
        }
        const bookingText = bookingInfo.textContent; // Use the text from the info box
        const whatsappNumber = "6282120750960"; // Your WhatsApp number
        const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(bookingText)}`;
        window.open(url, "_blank");
    }

    function resetSelection() {
        selectedCourse = "";
        selectedDay = "";
        selectedTime = "";
        courseSelect.value = "";
        dayButtons.forEach(b => b.classList.remove("active"));
        timeButtons.forEach(b => b.classList.remove("active"));
        updateBookingInfo(); // Hide info box
    }

    // Smooth scroll for hash links (if any, e.g., #ourprogram-form)
    window.addEventListener('DOMContentLoaded', () => {
        if (window.location.hash) {
            const target = document.querySelector(window.location.hash);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        }
    });
</script>

</body>
</html>