<?php
require 'koneksi.php';

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Pendaftar_User.xls");
header("Pragma: no-cache");
header("Expires: 0");

echo "<table border='1'>";
echo "<tr>
        <th>Fullname</th>
        <th>Username</th>
        <th>Course</th>
        <th>Email</th>
        <th>Tanggal</th>
      </tr>";

$result = mysqli_query($conn, "SELECT fullname, username, course, email, tanggal FROM register WHERE role = 'user'");

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>" . htmlspecialchars($row['fullname']) . "</td>
            <td>" . htmlspecialchars($row['username']) . "</td>
            <td>" . htmlspecialchars($row['course']) . "</td>
            <td>" . htmlspecialchars($row['email']) . "</td>
            <td>" . htmlspecialchars($row['tanggal']) . "</td>
          </tr>";
}
echo "</table>";
?>
