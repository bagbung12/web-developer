<?php
session_start();
require_once 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

$token = isset($_GET['token']) ? $_GET['token'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if (empty($password) || empty($confirm)) {
        $error = "Password tidak boleh kosong.";
    } elseif ($password !== $confirm) {
        $error = "Password dan konfirmasi tidak cocok.";
    } else {
        $current_time = date("Y-m-d H:i:s");
        $stmt = $conn->prepare("SELECT email FROM register WHERE reset_token = ? AND reset_token_expiry > ?");
        $stmt->bind_param("ss", $token, $current_time);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows === 1) {
            $row = $result->fetch_assoc();
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $update = $conn->prepare("UPDATE register SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE email = ?");
            $update->bind_param("ss", $hashed_password, $row['email']);
            $update->execute();

            $_SESSION['message'] = "Password berhasil direset. Silakan login.";
            header("Location: login2.php");
            exit();
        } else {
            $error = "Token tidak valid atau sudah kedaluwarsa.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Reset Password</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="min-height: 100vh;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow-sm">
          <div class="card-body">
            <h4 class="card-title text-center mb-4">Reset Password</h4>

            <?php if (!empty($error)): ?>
              <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST">
              <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
              <div class="mb-3">
                <label for="password" class="form-label">Password Baru</label>
                <input type="password" name="password" id="password" class="form-control" required>
              </div>
              <div class="mb-3">
                <label for="confirm" class="form-label">Konfirmasi Password</label>
                <input type="password" name="confirm" id="confirm" class="form-control" required>
              </div>
              <button type="submit" class="btn btn-primary w-100">Reset Password</button>
            </form>

            <div class="text-center mt-3">
              <a href="login2.php" class="text-decoration-none">&larr; Kembali ke Login</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
