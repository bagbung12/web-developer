<?php
session_start();
// date_default_timezone_set('Asia/Jakarta'); // Anda bisa uncomment ini jika perlu zona waktu spesifik
require 'koneksi.php';

// Inisialisasi variabel untuk keamanan dan default
$username = 'PROFIL';
$id_user = 0;
$notif_pesan = '';
$ada_notif = false;
$user_role = '';

// Cek apakah sesi user ada dan atur variabel terkait
if (isset($_SESSION['user'])) {
    $username = htmlspecialchars($_SESSION['user']['username'] ?? 'PROFIL');
    $id_user = (int)($_SESSION['user']['id'] ?? 0);
    $user_role = $_SESSION['user']['role'] ?? '';
}

// Logika notifikasi hanya untuk peran 'user'
if ($id_user > 0 && $user_role === 'user') {
    $stmt = $conn->prepare("SELECT notif_sertifikat FROM register WHERE id = ?");
    $stmt->bind_param("i", $id_user);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $stmt->close();

    if ($data && $data['notif_sertifikat'] == 1) {
        $notif_pesan = "🎉 Sertifikat kamu telah dikirim ke email.";
        $ada_notif = true;
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>MMC COURSE - Blog & Sejarah</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="icon" type="image/png" href="mmm.png">

    <style>
        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: url(download.jpeg) no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Main content takes remaining space */
        main {
            flex: 1;
            padding-top: 70px; /* Adjust for fixed navbar height */
        }

        /* Navbar Styling (Consistent with index1.php) */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030;
            position: fixed; /* Make navbar fixed */
            top: 0;
            width: 100%;
        }
        .navbar-brand img {
            height: 35px; /* Slightly larger */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd;
        }
        .navbar-nav .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
            border: none;
        }
        .navbar-nav .dropdown-item {
            color: #333;
            transition: background-color 0.2s ease;
            display: flex; /* Untuk menempatkan teks dan tombol hapus sejajar */
            justify-content: space-between; /* Menjauhkan teks dan tombol hapus */
            align-items: center;
        }
        .navbar-nav .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #0d6efd;
        }
        /* Style untuk tombol hapus notifikasi */
        .delete-notif-btn {
            background: none;
            border: none;
            color: #dc3545; /* Merah untuk ikon hapus */
            font-size: 0.9em;
            cursor: pointer;
            padding: 0 5px;
            margin-left: 10px; /* Jarak dari teks */
            opacity: 0.7;
            transition: opacity 0.2s ease;
        }
        .delete-notif-btn:hover {
            opacity: 1;
        }
        .notif-placeholder {
            padding: 0.5rem 1rem;
            color: #6c757d; /* Warna teks muted */
        }


        /* Content Section Styling */
        .content-section {
            background-color: rgba(255, 255, 255, 0.95); /* Semi-transparent white background */
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-top: 40px;
            margin-bottom: 40px;
        }
        .content-section h2, .content-section h4 {
            font-weight: 700;
            color: #0d6efd; /* Consistent blue color */
            margin-bottom: 25px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }
        .content-section p {
            font-size: 1.1rem;
            line-height: 1.7;
            color: #444;
            margin-bottom: 15px;
        }
        .content-section strong {
            color: #e67e22; /* Orange color for emphasis */
            font-weight: 600;
        }

        /* Image Gallery Styling */
        .gallery-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px; /* Space between images */
            justify-content: center;
            margin-top: 30px; /* Space from text content */
        }
        .gallery-container .img-fluid {
            width: 100%;
            height: 220px; /* Fixed height for consistent display */
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: default; /* No pointer for non-modal images */
        }
        .gallery-container .img-fluid:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }
        .gallery-col {
            flex: 1 1 calc(33.33% - 20px); /* Adjust based on gap */
            max-width: calc(33.33% - 20px);
            text-align: center; /* Center images if only one per row */
        }
        @media (max-width: 992px) {
            .gallery-col {
                flex: 1 1 calc(50% - 20px);
                max-width: calc(50% - 20px);
            }
        }
        @media (max-width: 576px) {
            .gallery-col {
                flex: 1 1 100%;
                max-width: 100%;
            }
        }

        /* Google Map */
        .map-section {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-bottom: 40px;
        }
        .map-section h4 {
            font-weight: 700;
            color: #0d6efd;
            margin-bottom: 25px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }
        .map-responsive {
            overflow: hidden;
            padding-bottom: 56.25%; /* 16:9 aspect ratio */
            position: relative;
            height: 0;
            border-radius: 8px;
        }
        .map-responsive iframe {
            left: 0;
            top: 0;
            height: 100%;
            width: 100%;
            position: absolute;
            border: 0;
            border-radius: 8px; /* Consistent border radius */
        }

        /* Footer (Consistent with index1.php) */
        footer {
            background: #222;
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: auto;
        }
        footer a {
            color: #FFC107;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .content-section {
                padding: 30px;
            }
            .content-section h2 {
                font-size: 1.8rem;
            }
            .content-section h4 {
                font-size: 1.3rem;
            }
            .content-section p {
                font-size: 1rem;
            }
            .map-section {
                padding: 30px;
            }
            .navbar-brand img {
                height: 30px;
            }
        }
    </style>
</head>
<body>

<div class="container-fluid px-0">

    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                <img src="mmm.png" alt="MMC Logo" class="me-2">
                MMC COURSE
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav gap-2">
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index1.php">HOME</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'blog.php' ? 'active' : '' ?>" href="blog.php">BLOG</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'service.php' ? 'active' : '' ?>" href="service.php">SERVICE</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'ourprogram.php' ? 'active' : '' ?>" href="ourprogram.php">OUR PROGRAM</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'contact.php' ? 'active' : '' ?>" href="contact.php">CONTACT</a></li>
                    
                    <?php if ($user_role === 'user'): ?>
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link position-relative dropdown-toggle" href="#" id="notifDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell"></i>
                                <?php if ($ada_notif): ?>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="notifBadge">
                                        1
                                        <span class="visually-hidden">unread messages</span>
                                    </span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notifDropdown" id="notifList">
                                <?php if ($ada_notif): ?>
                                    <li id="notifItem_sertifikat">
                                        <a class="dropdown-item text-success" href="#">
                                            <span><?= $notif_pesan ?></span>
                                            <button class="delete-notif-btn" data-notif-type="sertifikat">
                                                <i class="fas fa-times-circle"></i>
                                            </button>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li><span class="dropdown-item text-muted" id="noNotifMessage">Tidak ada notifikasi baru</span></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item dropdown">
                        <a class="btn btn-outline-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i> <?= $username ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['user'])): ?>
                                <li><a class="dropdown-item" href="edit_profil.php"><i class="fas fa-edit me-2"></i>Edit Profil</a></li>
                                <li><a class="dropdown-item" href="ganti_password.php"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="login2.php"><i class="fas fa-sign-in-alt me-2"></i>Login</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container">
        <section class="content-section">
            <div class="row align-items-center">
                <div class="col-md-6 mb-4 mb-md-0">
                    <h2 class="mb-3">Tentang MMC Course</h2>
                    <p>
                        LKP MMC bergerak di bidang pendidikan dengan membuka kursus bahasa Inggris, Jepang, Mandarin, Perancis, dan Komputer. Berdiri pada tanggal 1 Mei 1998 dengan nama Balai Pendidikan dan Pelatihan Mulya Mitra.
                    </p>
                    <p>
                        Pada tanggal 1 Mei 2000 dibentuk lembaga pendidikan yaitu MMC (Mulya Mitra College) dengan SK dari Departemen Pendidikan Nasional. Pada bulan Februari 2004 MMC mendapat Status <strong>A (SANGAT BAIK)</strong> dari DIKNAS.
                    </p>
                    <h4 class="mt-4">VISI</h4>
                    <p>Menjadi pusat penyelenggaraan pendidikan bahasa asing dan komputer yang meningkatkan kemampuan SDM.</p>
                    <h4>MISI</h4>
                    <p>Menyediakan pelatihan bahasa dan komputer yang berkualitas dan berorientasi pada kepuasan peserta.</p>
                </div>

                <div class="col-md-6">
                    <div class="gallery-container">
                        <div class="gallery-col">
                            <img src="gedung.png" class="img-fluid rounded" alt="Gedung MMC" />
                        </div>
                        <div class="gallery-col">
                            <img src="2.jpeg" class="img-fluid rounded" alt="Ruang Kelas 1" />
                        </div>
                        <div class="gallery-col">
                            <img src="3.jpeg" class="img-fluid rounded" alt="Ruang Kelas 2" />
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="map-section">
            <h4 class="mb-3">Lokasi MMC Course</h4>
            <div class="map-responsive">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.576311820757!2d107.62449527399772!3d-6.941131593058905!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e86322adc5e1%3A0x544b0838f18b4ac8!2sMMC%20Course!5e0!3m2!1sid!2sid!4v1742386764006!5m2!1sid!2sid"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                ></iframe>
            </div>
        </section>
    </main>

    <footer class="text-center">
        <div class="container">
            <p>© <?= date("Y") ?> MMC Course. All rights reserved.</p>
            <div class="social-icons">
                <p>Ikuti kami:</p>
                <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
 
<script>
    const notifBadge = document.getElementById('notifBadge'); // Badge angka 1
    const notifList = document.getElementById('notifList'); // Container ul dropdown notifikasi
    const notifItemSertifikat = document.getElementById('notifItem_sertifikat'); // Item notifikasi sertifikat
    const notifDropdown = document.getElementById('notifDropdown'); // Elemen <a> yang diklik untuk membuka dropdown

    // Fungsi untuk menampilkan/menyembunyikan pesan "Tidak ada notifikasi baru"
    function toggleNoNotifMessage() {
        if (!notifList) return;

        const isSertifNotifPresent = document.getElementById('notifItem_sertifikat') !== null;
        let noNotifMessage = document.getElementById('noNotifMessage');

        if (!isSertifNotifPresent) {
            if (!noNotifMessage) {
                const li = document.createElement('li');
                li.innerHTML = '<span class="dropdown-item text-muted" id="noNotifMessage">Tidak ada notifikasi baru</span>';
                notifList.appendChild(li);
            }
        } else {
            if (noNotifMessage) {
                noNotifMessage.parentElement.remove();
            }
        }
    }

    // Event listener untuk tombol hapus notifikasi sertifikat
    if (notifItemSertifikat) {
        const deleteBtn = notifItemSertifikat.querySelector('.delete-notif-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();

                const notifType = this.dataset.notifType;

                fetch('reset_notif.php?type=' + notifType)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok ' + response.statusText);
                        }
                        return response.text();
                    })
                    .then(data => {
                        if (data.trim() === 'ok') {
                            notifItemSertifikat.remove(); // Hapus item notifikasi

                            if (notifBadge) {
                                notifBadge.remove(); // Hapus badge saat notifikasi dihapus
                            }
                            
                            toggleNoNotifMessage(); // Perbarui pesan "Tidak ada notifikasi baru"

                        } else {
                            console.error('Server responded:', data);
                            alert('Gagal menghapus notifikasi. Silakan coba lagi. Pesan server: ' + data);
                        }
                    })
                    .catch(error => {
                        console.error('Error deleting notification:', error);
                        alert('Terjadi kesalahan saat menghapus notifikasi. Silakan cek konsol.');
                    });
            });
        }
    }

    // Event listener untuk saat lonceng notifikasi (dropdown) diklik
    if (notifDropdown) {
        notifDropdown.addEventListener('click', function() {
            if (notifBadge) {
                notifBadge.remove(); 
                fetch('reset_notif.php?type=sertifikat')
                    .then(response => {
                        if (!response.ok) {
                            console.error('Network response was not ok for dropdown click:', response.statusText);
                        }
                        return response.text();
                    })
                    .then(data => {
                        if (data.trim() !== 'ok') {
                            console.error('Server responded with error on dropdown click:', data);
                           
                        }
                      
                    })
                    .catch(error => {
                        console.error('Error resetting notification on dropdown click:', error);
                    });
                
            }
        });
    }

    document.addEventListener('DOMContentLoaded', toggleNoNotifMessage);
</script>

</body>
</html>