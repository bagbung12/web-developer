<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
require 'koneksi.php'; // Pastikan file koneksi.php ada dan benar

$username = isset($_SESSION['user']['username']) ? htmlspecialchars($_SESSION['user']['username']) : 'PROFIL';
$current_page = basename($_SERVER['PHP_SELF']);
$id_user = $_SESSION['user']['id'] ?? 0;
$notif_pesan = '';
$ada_notif = false;


if ($id_user > 0 && $_SESSION['user']['role'] === 'user') {
    $cek = mysqli_query($conn, "SELECT notif_sertifikat FROM register WHERE id = $id_user");
    $data = mysqli_fetch_assoc($cek);

    if ($data && $data['notif_sertifikat'] == 1) {
        $notif_pesan = "🎉 Sertifikat kamu telah dikirim ke email."; // Emoji yang lebih universal
        $ada_notif = true;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>MMC COURSE - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="icon" type="image/png" href="mmm.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url(download.jpeg) no-repeat center center fixed; /* Pastikan background fixed dan cover */
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
            min-height: 100vh; /* Agar footer selalu di bawah jika konten sedikit */
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1; /* Konten utama mengambil sisa ruang */
        }
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030; /* Pastikan navbar di atas elemen lain */
        }
        .navbar-brand img {
            height: 35px;
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            position: relative;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd;
        }
        /* Style untuk dropdown profil dan notifikasi */
        .navbar-nav .dropdown-toggle::after {
            vertical-align: middle;
            margin-left: .5em;
        }
        .navbar-nav .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
            border: none;
        }

        /* --- Global Section Styles --- */
        .section-container {
            background-color: rgba(255, 255, 255, 0.95); /* Sedikit transparan agar background terlihat */
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-bottom: 40px;
        }
        .section-title {
            font-weight: 700;
            color: #0d6efd;
            margin-bottom: 40px;
            text-align: center;
        }

        /* --- Gallery Section --- */
        .gallery-section {
            margin-top: 40px;
        }
        .gallery-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            padding: 5px;
            background-color: #f8f9fa; /* Latar belakang untuk gambar agar tidak polos */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }
        .gallery-img:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
        /* Modal */
        .modal-body {
            background-color: transparent;
        }
        .modal-content {
            background-color: transparent;
            border: none;
        }
        #modalImage {
            max-width: 100%;
            height: auto;
            display: block;
            margin: auto;
            border-radius: 8px;
        }

        /* --- Contact Buttons Section --- */
        .contact-buttons-section .btn {
            padding: 15px 35px;
            font-size: 1.2rem;
            border-radius: 50px;
            margin: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .contact-buttons-section .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }
        .contact-buttons-section .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .contact-buttons-section .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        .contact-buttons-section .btn-instagram {
            background-color: #e83e8c;
            border-color: #e83e8c;
            color: white;
        }
        .contact-buttons-section .btn-instagram:hover {
            background-color: #d12e7b;
            border-color: #c02a70;
        }

        /* --- Komentar & Rating Section --- */
        .komentar-section {
            margin-top: 60px; /* Jarak lebih besar dari bagian atas */
            padding: 40px;
        }
        .komentar-box {
            background-color: #f8f9fa; /* Latar belakang komentar box yang lebih lembut */
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 20px;
            padding: 20px;
            border-left: 5px solid #0d6efd; /* Garis biru di samping */
        }
        .komentar-box strong {
            color: #0d6efd;
            font-size: 1.1rem;
        }
        .komentar-box small {
            font-size: 0.85rem;
            color: #888;
        }
        .komentar-box p {
            margin-top: 10px;
            line-height: 1.6;
        }
        .bintang {
            display: inline-block;
            direction: rtl; /* Untuk mengatur bintang dari kanan ke kiri */
        }
        .bintang input[type="radio"] {
            display: none;
        }
        .bintang label {
            font-size: 2.5rem; /* Ukuran bintang lebih besar */
            color: #ccc; /* Warna default abu-abu */
            cursor: pointer;
            padding: 0 5px; /* Jarak antar bintang */
            transition: color 0.3s ease;
        }
        .bintang input:checked ~ label,
        .bintang label:hover,
        .bintang label:hover ~ label {
            color: #ffc107; /* Warna emas */
        }
        .bintang label:before {
            content: '★'; /* Menggunakan karakter bintang Unicode */
        }
        .bintang.display-only label { /* Untuk display rating yang sudah ada */
            font-size: 1.5rem;
            color: #ffc107;
            cursor: default;
            padding: 0 2px;
        }
        .bintang.display-only label:before {
            content: '★';
        }

        /* Form styling */
        .komentar-section form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        .komentar-section .form-control {
            border-radius: 0.5rem;
            border-color: #dee2e6;
            padding: 10px 15px;
        }
        .komentar-section .btn {
            border-radius: 50px;
            padding: 10px 25px;
            font-size: 1.05rem;
            transition: all 0.3s ease;
        }
        .komentar-section .btn:hover {
            transform: translateY(-2px);
        }
        .komentar-section .alert {
            border-radius: 0.5rem;
            padding: 15px;
        }

        /* Footer */
        footer {
            background: #222;
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: auto; /* Mendorong footer ke bawah */
        }
        footer a {
            color: #FFC107;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="mmm.png" alt="MMC Logo" class="me-2" />
            MMC COURSE
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav gap-2">
                <li class="nav-item"><a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index1.php">HOME</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'blog.php' ? 'active' : '' ?>" href="blog.php">BLOG</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'service.php' ? 'active' : '' ?>" href="service.php">SERVICE</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'ourprogram.php' ? 'active' : '' ?>" href="ourprogram.php">OUR PROGRAM</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'contact.php' ? 'active' : '' ?>" href="contact.php">CONTACT</a></li>
                <?php if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'user'): ?>
                    <li class="nav-item dropdown me-3">
                        <a class="nav-link position-relative dropdown-toggle" href="#" id="notifDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bell"></i>
                            <?php if ($ada_notif): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                    1
                                    <span class="visually-hidden">unread messages</span>
                                </span>
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notifDropdown">
                            <?php if ($ada_notif): ?>
                                <li><span class="dropdown-item text-success"><?= $notif_pesan ?></span></li>
                            <?php else: ?>
                                <li><span class="dropdown-item text-muted">Tidak ada notifikasi baru</span></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <li class="nav-item dropdown">
                    <a class="btn btn-outline-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-1"></i> <?= $username ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php if (isset($_SESSION['user'])): ?>
                            <li><a class="dropdown-item" href="edit_profil.php"><i class="fas fa-edit me-2"></i>Edit Profil</a></li>
                            <li><a class="dropdown-item" href="ganti_password.php"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        <?php else: ?>
                            <li><a class="dropdown-item" href="login2.php"><i class="fas fa-sign-in-alt me-2"></i>Login</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main class="container my-5">
    <div class="section-container gallery-section">
        <h2 class="section-title">Galeri Kegiatan Kami</h2>
        <div class="row g-3"> <?php
            $images = ['mmc.jpg','mmc1.jpg','mmc2.jpg','mmc3.jpg','mmc4.jpg','mmc5.jpg','mmc6.jpg','mmc7.jpg','mmc8.jpg'];
            foreach ($images as $img) {
                echo '<div class="col-6 col-md-4 col-lg-3">
                        <img src="' . $img . '" alt="MMC Course Activity" class="gallery-img" data-bs-toggle="modal" data-bs-target="#imageModal" data-img="' . $img . '">
                      </div>';
            }
            ?>
        </div>
    </div>

    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <img src="" class="img-fluid rounded" id="modalImage" alt="Preview">
                </div>
            </div>
        </div>
    </div>

    <div class="section-container contact-buttons-section text-center">
        <h2 class="section-title">Hubungi Kami!</h2>
        <p class="lead mb-4 text-muted">Jangan ragu untuk menghubungi kami jika Anda memiliki pertanyaan atau ingin mendaftar.</p>
        <div class="d-flex flex-column flex-md-row justify-content-center">
            <a href="https://wa.me/6282120750960" class="btn btn-success btn-lg" target="_blank">
                <i class="fab fa-whatsapp me-2"></i>Hubungi via WhatsApp
            </a>
            <a href="https://www.instagram.com/mmc_course" class="btn btn-instagram btn-lg" target="_blank">
                <i class="fab fa-instagram me-2"></i>Ikuti Kami di Instagram
            </a>
        </div>
    </div>

    <div class="section-container komentar-section">
        <h2 class="section-title">Komentar & Penilaian</h2>
        <?php if (isset($_SESSION['user'])):
            $username_session = $_SESSION['user']['username'];
            $email_session = $_SESSION['user']['email'];
        ?>
        <form action="simpan_komentar.php" method="POST">
            <input type="hidden" name="username" value="<?= htmlspecialchars($username_session) ?>">
            <input type="hidden" name="email" value="<?= htmlspecialchars($email_session) ?>">

            <div class="mb-4 text-center">
                <label class="form-label d-block fs-5 mb-2 fw-semibold">Beri Rating Kami:</label>
                <div class="bintang d-inline-block">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" required>
                        <label for="star<?= $i ?>" title="<?= $i ?> stars"></label>
                    <?php endfor; ?>
                </div>
            </div>

            <div class="mb-3">
                <label for="komentar_text" class="form-label fw-semibold">Komentar Anda:</label>
                <textarea id="komentar_text" name="komentar" class="form-control" rows="4" placeholder="Tulis komentar Anda tentang pengalaman Anda di MMC Course..." required></textarea>
            </div>

            <div class="d-flex flex-column flex-md-row justify-content-center gap-3 mt-4">
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane me-2"></i>Kirim Komentar</button>
                <a href="https://www.google.com/maps/search/?api=1&query=MMC+COURSE&query_place_id=ChIJ0wE0P9_c_jYRHsC4s-sX8G4" target="_blank" class="btn btn-success"><i class="fas fa-star me-2"></i>Tulis Review di Google Maps</a>
            </div>
        </form>

        <hr class="my-5">
        <div class="text-center mb-4">
            <h5 class="text-success fw-bold">Sudah kasih rating di Google Maps? Klaim Voucher Anda!</h5>
            <p class="text-muted">Masukkan email yang Anda gunakan untuk review di Google Maps.</p>
        </div>
        <form action="kirim_voucher.php" method="POST" class="d-flex flex-column flex-md-row justify-content-center align-items-center gap-3">
            <div class="flex-grow-1" style="max-width: 350px;">
                <input type="email" name="email" class="form-control form-control-lg" placeholder="Masukkan email Anda" required>
            </div>
            <button type="submit" class="btn btn-warning btn-lg"><i class="fas fa-gift me-2"></i>Klaim Voucher</button>
        </form>
        <?php if (isset($_GET['status']) && $_GET['status'] == 'voucher_sent'): ?>
            <div class="alert alert-success text-center mt-4 animated fadeIn">
                🎉 Voucher berhasil dikirim ke email Anda! Cek folder inbox atau spam.
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['status']) && $_GET['status'] == 'email_not_found'): ?>
            <div class="alert alert-danger text-center mt-4 animated fadeIn">
                Email tidak ditemukan. Pastikan email yang Anda masukkan sudah pernah melakukan review.
            </div>
        <?php endif; ?>

        <?php else: ?>
            <p class="text-center lead"><a href="login2.php" class="btn btn-primary btn-lg"><i class="fas fa-sign-in-alt me-2"></i>Login</a> untuk menulis komentar & penilaian.</p>
        <?php endif; ?>

       <?php
        $query_komentar = $conn->query("SELECT komentar.email, komentar.komentar, komentar.waktu, rating.rate FROM komentar LEFT JOIN rating ON komentar.email = rating.email ORDER BY komentar.waktu DESC LIMIT 10");
        if ($query_komentar && $query_komentar->num_rows > 0):
        ?>
            <hr class="my-5">
            <h4 class="text-center section-title">Komentar Terbaru dari Siswa Kami</h4>

            <?php while ($row = $query_komentar->fetch_assoc()): ?>
                <div class="komentar-box">
                    <strong><?= htmlspecialchars($row['email']) ?></strong>
                    <small class="text-muted float-end"><?= date('d-m-Y H:i', strtotime($row['waktu'])) ?></small>

                    <?php if (!empty($row['rate'])): ?>
                        <div class="text-warning mt-2 bintang display-only" style="display:inline-block; vertical-align: middle;">
                            <?php
                            $rating = (int)$row['rate']; // Ambil rating dari database (misal: 3)
                            $max_stars = 5; // Maksimal bintang yang ditampilkan adalah 5
                            
                            // Tampilkan bintang terisi (sesuai rating)
                            for ($i = 0; $i < $rating; $i++):
                            ?>
                                <label class="text-warning"></label> <?php endfor; ?>

                            <?php
                            // Tampilkan bintang kosong (sisanya hingga 5)
                            for ($i = 0; $i < ($max_stars - $rating); $i++):
                            ?>
                                <label class="text-secondary"></label> <?php endfor; ?>
                        </div>
                    <?php endif; ?>

                    <p class="mt-2"><?= htmlspecialchars($row['komentar']) ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-center text-muted mt-5">Belum ada komentar atau penilaian. Jadilah yang pertama!</p>
        <?php endif; ?>
    </div>
</main>

<footer class="text-center">
    <div class="container">
        <p>&copy; <?= date("Y") ?> MMC Course. All rights reserved.</p>
        <div class="social-icons">
            <p>Ikuti kami:</p>
            <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram"></i></a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Script untuk Notifikasi Sertifikat
    const notifBell = document.getElementById('notifDropdown');
    if (notifBell) {
        notifBell.addEventListener('click', function () {
            const badge = notifBell.querySelector('.badge');
            if (badge) {
                fetch('reset_notif.php')
                    .then(response => response.text())
                    .then(data => {
                        if (data.trim() === 'ok') {
                            badge.remove();
                            // Optional: Update the dropdown content to "Tidak ada notifikasi baru"
                            const dropdownMenu = notifBell.nextElementSibling;
                            if (dropdownMenu) {
                                dropdownMenu.innerHTML = '<li><span class="dropdown-item text-muted">Tidak ada notifikasi baru</span></li>';
                            }
                        }
                    })
                    .catch(error => console.error('Error resetting notification:', error));
            }
        });
    }

    // Script Modal Preview Gambar
    const galleryImages = document.querySelectorAll('.gallery-img');
    const modalImage = document.getElementById('modalImage');

    galleryImages.forEach(img => {
        img.addEventListener('click', () => {
            modalImage.src = img.getAttribute('data-img');
        });
    });

    // Script untuk Rating Bintang (agar bisa di-klik dengan benar)
    document.addEventListener('DOMContentLoaded', function() {
        const ratingInputs = document.querySelectorAll('.bintang input[type="radio"]');
        ratingInputs.forEach(input => {
            input.addEventListener('change', function() {
                // Remove gold from all labels in this group
                const labels = this.parentElement.querySelectorAll('label');
                labels.forEach(label => label.style.color = '#ccc');

                // Add gold to checked and previous labels
                let current = this;
                while (current) {
                    if (current.tagName === 'INPUT' && current.type === 'radio') {
                        const label = this.parentElement.querySelector(`label[for="${current.id}"]`);
                        if (label) {
                            label.style.color = 'gold';
                        }
                    } else if (current.tagName === 'LABEL') {
                        current.style.color = 'gold';
                    }
                    current = current.nextElementSibling; // Move to the next sibling (label)
                }
            });
        });
    });
</script>

</body>
</html>