<?php
// kirim_promo_massal.php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'koneksi.php'; // Pastikan path ini benar
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login2.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = $_POST['judul'] ?? '';
    $pesan = $_POST['pesan'] ?? '';
    $selectedUserIds = $_POST['selected_users_ids'] ?? ''; // Ini akan berisi string ID dipisahkan koma

    // Validasi input
    if (empty($judul) || empty($pesan)) {
        echo "<script>alert('Judul dan Pesan Promo tidak boleh kosong.'); window.location.href='dashboard.php';</script>";
        exit();
    }

    if (empty($selectedUserIds)) {
        echo "<script>alert('Tidak ada user yang dipilih untuk dikirimi promo.'); window.location.href='dashboard.php';</script>";
        exit();
    }

    $ids = explode(',', $selectedUserIds);
    $safe_ids = array_map('intval', $ids); // Pastikan ID adalah integer
    $id_list = implode(',', $safe_ids);

    // Ambil data email dari database berdasarkan ID yang dipilih
    $query_users = "SELECT id, email FROM register WHERE id IN ($id_list) AND role = 'user'";
    $result_users = mysqli_query($conn, $query_users);

    if (!$result_users) {
        echo "<script>alert('Error mengambil data user: " . mysqli_error($conn) . "'); window.location.href='dashboard.php';</script>";
        exit();
    }

    $emails_to_send = [];
    $ids_to_update = []; // Untuk menyimpan ID yang berhasil dikirimi email
    while ($user = mysqli_fetch_assoc($result_users)) {
        $emails_to_send[] = htmlspecialchars($user['email']);
        $ids_to_update[] = $user['id'];
    }

    if (empty($emails_to_send)) {
        echo "<script>alert('Tidak ada email yang ditemukan untuk user terpilih.'); window.location.href='dashboard.php';</script>";
        exit();
    }

    // PHPMailer Configuration
    require 'vendor/autoload.php';
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host       = 'mmccourse.my.id'; 
        $mail->SMTPAuth   = true;
        $mail->Username   = 'mmccourse@mmccourse.my.id'; 
        $mail->Password   = 'mmcoke123@';   
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
        $mail->Port       = 587; 

        //Recipients
        $mail->setFrom('mmccourse@mmccourse.my.id', 'MMC_COURSE'); // 

     
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == UPLOAD_ERR_OK) {
            $file_tmp_name = $_FILES['attachment']['tmp_name'];
            $file_name = basename($_FILES['attachment']['name']);
            $file_size = $_FILES['attachment']['size'];
            $file_type = $_FILES['attachment']['type'];

            // Batasan ukuran file (2MB)
            if ($file_size > 2 * 1024 * 1024) {
                echo "<script>alert('Ukuran file lampiran terlalu besar (maksimal 2MB).'); window.location.href='dashboard.php';</script>";
                exit();
            }

            // Batasan tipe file
            $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
            if (!in_array($file_type, $allowed_types)) {
                echo "<script>alert('Format file lampiran tidak diizinkan. Hanya JPG, PNG, PDF.'); window.location.href='dashboard.php';</script>";
                exit();
            }

            $mail->addAttachment($file_tmp_name, $file_name);
        }

        // Content
        $mail->isHTML(true);
        $mail->Subject = $judul;
        $mail->Body    = nl2br($pesan); // Mengganti baris baru dengan <br> untuk HTML
        $mail->AltBody = strip_tags($pesan); // Versi teks biasa

        $success_count = 0;
        $failed_emails = [];

        foreach ($emails_to_send as $email) {
            $mail->clearAddresses(); // Hapus semua alamat sebelumnya
            $mail->addAddress($email); // Tambahkan alamat penerima saat ini

            try {
                $mail->send();
                $success_count++;
            } catch (Exception $e) {
                $failed_emails[] = $email . " (Error: {$mail->ErrorInfo})";
            }
        }

        // Update status promo di database untuk ID yang berhasil dikirimi email
        if (!empty($ids_to_update)) {
            $update_ids_list = implode(',', $ids_to_update);
            $update_query = "UPDATE register SET status_promo = 'sudah' WHERE id IN ($update_ids_list)";
            mysqli_query($conn, $update_query);
        }

        $message = "Promo berhasil dikirim ke " . $success_count . " user.";
        if (!empty($failed_emails)) {
            $message .= "\\nBerikut email yang gagal dikirim:\\n" . implode("\\n", $failed_emails);
        }
        echo "<script>alert('" . $message . "'); window.location.href='dashboard.php';</script>";

    } catch (Exception $e) {
        echo "<script>alert('Gagal mengirim promo. Mailer Error: {$mail->ErrorInfo}'); window.location.href='dashboard.php';</script>";
    }
} else {
    echo "<script>alert('Metode request tidak diizinkan.'); window.location.href='dashboard.php';</script>";
}

mysqli_close($conn);
exit();
?>