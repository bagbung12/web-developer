<?php
session_start();
$username = isset($_SESSION['user']['username']) ? htmlspecialchars($_SESSION['user']['username']) : 'PROFIL';
$current_page = basename($_SERVER['PHP_SELF']); // Ini akan menjadi 'blog1.php'
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>MMC COURSE - Blog & Sejarah</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="icon" type="image/png" href="mmm.png">

    <style>
        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', sans-serif; /* Menggunakan Poppins */
            background: url(download.jpeg) no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Navbar Styling (Consistent with index1.php) */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030;
            position: fixed; /* Make navbar fixed */
            top: 0;
            width: 100%;
        }
        .navbar-brand img {
            height: 35px; /* Slightly larger */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd;
        }
        .navbar-nav .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
            border: none;
        }
        .navbar-nav .dropdown-item {
            color: #333;
            transition: background-color 0.2s ease;
        }
        .navbar-nav .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #0d6efd;
        }
        
        /* Main Content Styling */
        main {
            flex: 1;
            padding-top: 70px; /* Adjust for fixed navbar height */
        }
        .content-section {
            background-color: rgba(255, 255, 255, 0.95); /* Semi-transparent white background */
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-top: 40px;
            margin-bottom: 40px;
        }
        .content-section h2, .content-section h4 {
            font-weight: 700;
            color: #0d6efd; /* Consistent blue color */
            margin-bottom: 25px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }
        .content-section p {
            font-size: 1.1rem;
            line-height: 1.7;
            color: #444;
            margin-bottom: 15px;
        }
        .content-section strong {
            color: #e67e22; /* Orange color for emphasis */
            font-weight: 600;
        }

        /* Image Gallery Styling */
        .gallery-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px; /* Space between images */
            justify-content: center;
        }
        .gallery-container .img-fluid {
            width: 100%;
            height: 220px; /* Fixed height for consistent display */
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }
        .gallery-container .img-fluid:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }
        .gallery-col {
            flex: 1 1 calc(33.33% - 20px); /* Adjust based on gap */
            max-width: calc(33.33% - 20px);
            text-align: center; /* Center images if only one per row */
        }
        @media (max-width: 992px) {
            .gallery-col {
                flex: 1 1 calc(50% - 20px);
                max-width: calc(50% - 20px);
            }
        }
        @media (max-width: 576px) {
            .gallery-col {
                flex: 1 1 100%;
                max-width: 100%;
            }
        }

        /* Modal Preview Gambar */
        #imageModal .modal-content {
            background-color: transparent;
            border: none;
        }
        #modalImage {
            max-height: 90vh; /* Max height for larger screens */
            width: auto; /* Maintain aspect ratio */
            display: block;
            margin: auto; /* Center the image */
            box-shadow: 0 5px 20px rgba(0,0,0,0.5);
            border-radius: 8px;
        }
        /* Override default Bootstrap modal padding for full image view */
        #imageModal .modal-body {
            padding: 0;
        }

        /* Google Map */
        .map-section {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-bottom: 40px;
        }
        .map-section h4 {
            font-weight: 700;
            color: #0d6efd;
            margin-bottom: 25px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }
        .map-responsive {
            overflow: hidden;
            padding-bottom: 56.25%; /* 16:9 aspect ratio */
            position: relative;
            height: 0;
            border-radius: 8px;
        }
        .map-responsive iframe {
            left: 0;
            top: 0;
            height: 100%;
            width: 100%;
            position: absolute;
            border: 0;
            border-radius: 8px; /* Consistent border radius */
        }

        /* Footer (Consistent with index1.php) */
        footer {
            background: #222;
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: auto;
        }
        footer a {
            color: #FFC107;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .content-section {
                padding: 30px;
            }
            .content-section h2 {
                font-size: 1.8rem;
            }
            .content-section h4 {
                font-size: 1.3rem;
            }
            .content-section p {
                font-size: 1rem;
            }
            .map-section {
                padding: 30px;
            }
            .navbar-brand img {
                height: 30px;
            }
        }
    </style>
</head>
<body>

<div class="container-fluid px-0">

    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                <img src="mmm.png" alt="MMC Logo" class="me-2">
                MMC COURSE
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav gap-2">
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index.php">HOME</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'blog1.php' ? 'active' : '' ?>" href="blog1.php">BLOG</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'service1.php' ? 'active' : '' ?>" href="service1.php">SERVICE</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'contact1.php' ? 'active' : '' ?>" href="contact1.php">CONTACT</a></li>
                     <li class="nav-item"><a class="nav-link <?= $current_page == 'login2.php' ? 'active' : '' ?>" href="login2.php">LOGIN</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container">
        <section class="content-section">
            <div class="row align-items-center">
                <div class="col-md-6 mb-4 mb-md-0">
                    <h2 class="mb-3">Tentang MMC Course</h2>
                    <p>
                        LKP MMC bergerak di bidang pendidikan dengan membuka kursus bahasa Inggris, Jepang, Mandarin, Perancis, dan Komputer. Berdiri pada tanggal 1 Mei 1998 dengan nama Balai Pendidikan dan Pelatihan Mulya Mitra.
                    </p>
                    <p>
                        Pada tanggal 1 Mei 2000 dibentuk lembaga pendidikan yaitu MMC (Mulya Mitra College) dengan SK dari Departemen Pendidikan Nasional. Pada bulan Februari 2004 MMC mendapat Status <strong>A (SANGAT BAIK)</strong> dari DIKNAS.
                    </p>
                    <h4 class="mt-4">VISI</h4>
                    <p>Menjadi pusat penyelenggaraan pendidikan bahasa asing dan komputer yang meningkatkan kemampuan SDM.</p>
                    <h4>MISI</h4>
                    <p>Menyediakan pelatihan bahasa dan komputer yang berkualitas dan berorientasi pada kepuasan peserta.</p>
                </div>

                <div class="col-md-6">
                    <div class="gallery-container">
                        <div class="gallery-col">
                            <img src="gedung.png" class="img-fluid rounded preview-img" alt="Gedung MMC" data-img="gedung.png" />
                        </div>
                        <div class="gallery-col">
                            <img src="2.jpeg" class="img-fluid rounded preview-img" alt="Ruang Kelas 1" data-img="2.jpeg" />
                        </div>
                        <div class="gallery-col">
                            <img src="3.jpeg" class="img-fluid rounded preview-img" alt="Ruang Kelas 2" data-img="3.jpeg" />
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="map-section">
            <h4 class="mb-3">Lokasi MMC Course</h4>
            <div class="map-responsive">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.576311820757!2d107.62449527399772!3d-6.941131593058905!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e86322adc5e1%3A0x544b0838f18b4ac8!2sMMC%20Course!5e0!3m2!1sid!2sid!4v1742386764006!5m2!1sid!2sid"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                ></iframe>
            </div>
        </section>
    </main>

    <div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content bg-transparent border-0">
                <div class="modal-body p-0">
                    <img src="" id="modalImage" class="img-fluid rounded" alt="Preview" />
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p>&copy; <?= date("Y") ?> MMC Course. All rights reserved.</p>
            <div class="social-icons">
                <p>Ikuti kami:</p>
                <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const previewImgs = document.querySelectorAll('.preview-img');
    const modalImg = document.getElementById('modalImage');
    const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));

    previewImgs.forEach(img => {
        img.addEventListener('click', () => {
            modalImg.src = img.getAttribute('data-img');
            imageModal.show();
        });
    });
</script>

</body>
</html>