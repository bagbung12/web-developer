<?php
require 'koneksi.php';

$search = $_GET['q'] ?? '';
$course = $_GET['course'] ?? '';
$tanggal = $_GET['tanggal'] ?? '';

$search = mysqli_real_escape_string($conn, $search);
$course = mysqli_real_escape_string($conn, $course);
$tanggal = mysqli_real_escape_string($conn, $tanggal);

// Bangun WHERE clause dinamis
$where = "role = 'user'";

if (!empty($search)) {
    $where .= " AND (fullname LIKE '%$search%' OR email LIKE '%$search%' OR username LIKE '%$search%')";
}

if (!empty($course)) {
    $where .= " AND course = '$course'";
}

if (!empty($tanggal)) {
    $where .= " AND tanggal LIKE '$tanggal%'";
}


$query = "SELECT * FROM register WHERE $where ORDER BY id DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo "<tr><td colspan='10'>Terjadi kesalahan mengambil data.</td></tr>"; // Ubah colspan menjadi 10 karena ada 10 kolom
    exit;
}

if (mysqli_num_rows($result) === 0) {
    echo "<tr><td colspan='10'>Tidak ada data ditemukan.</td></tr>"; // Ubah colspan menjadi 10
}

while ($row = mysqli_fetch_assoc($result)) {
    $status_promo = ($row['status_promo'] === 'sudah') ?
        "<span class='badge bg-success'>Sudah Dipromosi</span>" :
        "<span class='badge bg-secondary'>Belum Dipromosi</span>";

    echo "<tr>
        <td><input type='checkbox' name='selected_users[]' value='" . $row['id'] . "'></td> <td>" . htmlspecialchars($row['fullname']) . "</td>
        <td>" . htmlspecialchars($row['username']) . "</td>
        <td>" . htmlspecialchars($row['course']) . "</td>
        <td>" . htmlspecialchars($row['email']) . "</td>
        <td>" . htmlspecialchars($row['tanggal']) . "</td>
        <td>" . (!empty($row['no_hp']) ? htmlspecialchars($row['no_hp']) : "<span class='text-danger'>Kosong</span>") . "</td>
        <td>" . (isset($row['tipe_no_hp']) ? htmlspecialchars($row['tipe_no_hp']) : "<span class='text-danger'>Tidak Ada</span>") . "</td>
        <td>$status_promo</td>
        <td class='no-print'>
            <form action='reset_promo.php' method='POST' style='display:inline;' onsubmit='return confirm(\"Reset status promo user ini?\")'>
                <input type='hidden' name='id' value='" . $row['id'] . "'>
                <button type='submit' class='btn btn-outline-secondary btn-sm'>Reset Promo</button>
            </form>
            <a href='edit_register.php?id=" . $row['id'] . "' class='btn btn-sm btn-warning ms-1'>Edit</a>
            <form action='hapus_register.php' method='POST' style='display:inline;' onsubmit='return confirm(\"Yakin ingin menghapus data ini?\");'>
                <input type='hidden' name='id' value='" . $row['id'] . "'>
                <button type='submit' class='btn btn-sm btn-danger ms-1'>Hapus</button>
            </form>
        </td>
    </tr>";
}
?>