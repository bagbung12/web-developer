<?php
session_start();
date_default_timezone_set('Asia/Jakarta');

$username = isset($_SESSION['user']['username']) ? htmlspecialchars($_SESSION['user']['username']) : 'PROFIL';
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>MMC COURSE - CONTACT</title> <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="icon" type="image/png" href="mmm.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet"> <style>
        body {
            font-family: 'Poppins', sans-serif; /* Menggunakan Poppins */
            background: url(download.jpeg); /* Background asli Anda */
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333; /* Warna teks default */
        }
        .navbar-brand img {
            height: 35px; /* Sedikit lebih besar */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd; /* Warna biru Bootstrap */
        }

        /* --- Perbaikan untuk Galeri --- */
        .gallery-section {
            padding: 60px 0; /* Padding lebih baik */
            background-color: rgba(255, 255, 255, 0.9); /* Latar belakang semi-transparan putih agar konten terbaca di atas background image */
            border-radius: 10px; /* Sudut membulat untuk section */
            margin-top: 40px; /* Jarak dari navbar */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); /* Bayangan untuk section */
        }
        .gallery-section h2 {
            font-weight: 600;
            color: #0d6efd; /* Warna judul */
            margin-bottom: 40px;
            text-align: center;
        }
        .gallery-img {
            width: 100%;
            height: 200px; /* Ukuran gambar sedikit lebih besar dan konsisten */
            object-fit: cover; /* Memastikan gambar mengisi area tanpa terdistorsi */
            border-radius: 8px; /* Sudut gambar membulat */
            padding: 5px;
            margin-bottom: 15px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Bayangan pada gambar */
            transition: transform 0.3s ease, box-shadow 0.3s ease; /* Transisi untuk hover */
        }
        .gallery-img:hover {
            transform: translateY(-5px); /* Efek sedikit naik saat di-hover */
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15); /* Bayangan lebih kuat saat di-hover */
        }

        /* Modal styling (diambil dari versi sebelumnya) */
        .modal-body {
            background-color: transparent;
        }
        .modal-content {
            background-color: transparent;
        }
        #modalImage {
            max-width: 100%;
            height: auto;
            display: block;
            margin: auto;
            border-radius: 8px; /* Pastikan gambar di modal juga membulat */
        }

        /* --- Perbaikan untuk Tombol Kontak --- */
        .contact-buttons-section {
            padding: 60px 0;
            background-color: rgba(255, 255, 255, 0.9); /* Latar belakang semi-transparan putih */
            border-radius: 10px;
            margin-top: 40px; /* Jarak dari galeri */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .contact-buttons-section h2 {
            font-weight: 600;
            color: #0d6efd;
            margin-bottom: 20px;
        }
        .contact-buttons-section p.lead {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 40px;
        }
        .contact-buttons-section .btn {
            padding: 15px 35px;
            font-size: 1.2rem;
            border-radius: 50px; /* Tombol membulat */
            margin: 10px; /* Jarak antar tombol */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .contact-buttons-section .btn:hover {
            transform: translateY(-3px); /* Efek sedikit naik saat di-hover */
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }
        .contact-buttons-section .btn-success {
            background-color: #28a745; /* Warna hijau WhatsApp */
            border-color: #28a745;
            color: white;
        }
        .contact-buttons-section .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        .contact-buttons-section .btn-instagram {
            background-color: #e83e8c; /* Warna Instagram */
            border-color: #e83e8c;
            color: white;
        }
        .contact-buttons-section .btn-instagram:hover {
            background-color: #d12e7b;
            border-color: #c02a70;
        }

        footer {
            background: #222; /* Warna footer lebih gelap */
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: 40px; /* Jarak dari bagian atas */
        }
        footer a {
            color: #FFC107; /* Warna kuning untuk link */
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">
            <img src="mmm.png" alt="MMC Logo" class="me-2" />
            MMC COURSE
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav gap-2">
                <li class="nav-item"><a class="nav-link <?= $current_page == 'index.php' ? 'active' : '' ?>" href="index.php">HOME</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'blog1.php' ? 'active' : '' ?>" href="blog1.php">BLOG</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'service1.php' ? 'active' : '' ?>" href="service1.php">SERVICE</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'contact1.php' ? 'active' : '' ?>" href="contact1.php">CONTACT</a></li>
                <li class="nav-item"><a class="nav-link <?= $current_page == 'login2.php' ? 'active' : '' ?>" href="login2.php">LOGIN</a></li>
            </ul>
        </div>
    </div>
</nav>

<section class="gallery-section text-center">
    <div class="container">
        <h2>Galeri Kegiatan Kami</h2>
        <div class="row">
            <?php
            $images = ['mmc.jpg','mmc1.jpg','mmc2.jpg','mmc3.jpg','mmc4.jpg','mmc5.jpg','mmc6.jpg','mmc7.jpg','mmc8.jpg'];
            foreach ($images as $img) {
                echo '<div class="col-6 col-md-4 col-lg-3">
                        <img src="' . $img . '" alt="MMC Course Activity" class="gallery-img" data-bs-toggle="modal" data-bs-target="#imageModal" data-img="' . $img . '">
                      </div>';
            }
            ?>
        </div>
    </div>
</section>

<div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body p-0">
                <img src="" class="img-fluid rounded" id="modalImage" alt="Preview">
            </div>
        </div>
    </div>
</div>

<section class="contact-buttons-section text-center">
    <div class="container">
        <h2>Hubungi Kami!</h2>
        <p class="lead mb-4">Jangan ragu untuk menghubungi kami jika Anda memiliki pertanyaan atau ingin mendaftar.</p>
        <div class="d-flex flex-column flex-md-row justify-content-center">
            <a href="https://wa.me/6282120750960" class="btn btn-success btn-lg" target="_blank">
                <i class="fab fa-whatsapp me-2"></i>Hubungi via WhatsApp
            </a>
            <a href="https://www.instagram.com/mmc_course" class="btn btn-instagram btn-lg" target="_blank">
                <i class="fab fa-instagram me-2"></i>Ikuti Kami di Instagram
            </a>
        </div>
    </div>
</section>

<footer class="text-center">
    <div class="container">
        <p>&copy; <?= date("Y") ?> MMC Course. All rights reserved.</p>
        <div class="social-icons">
            <p>Ikuti kami:</p>
            <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram"></i></a>
        </div>
    </div>
</footer>

<script>
    const galleryImages = document.querySelectorAll('.gallery-img');
    const modalImage = document.getElementById('modalImage');

    galleryImages.forEach(img => {
        img.addEventListener('click', () => {
            modalImage.src = img.getAttribute('data-img');
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>