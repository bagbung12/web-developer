<?php
session_start();
require 'koneksi.php';

// Cek apakah user admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login2.php");
    exit();
}

$id = $_POST['id'] ?? 0;

// Jalankan hanya jika request method POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi file
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== 0) {
        echo "Terjadi error saat upload file.";
        exit();
    }

    $nama_file = basename($_FILES['file']['name']);
    $tmp = $_FILES['file']['tmp_name'];
    $ext = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));
    $file_type = $_FILES['file']['type'];

    $allowed_types = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    $allowed_extensions = ['pdf', 'doc', 'docx'];

    if (!in_array($file_type, $allowed_types) || !in_array($ext, $allowed_extensions)) {
        echo "Hanya file PDF atau Word yang diperbolehkan.";
        exit();
    }

    // Buat nama unik untuk file
    $path = "uploads/" . time() . "_" . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $nama_file);

    // Cek folder uploads writable
    if (!is_writable('uploads')) {
        echo "Folder uploads tidak bisa ditulis.";
        exit();
    }
    echo "Folder ada? " . (is_dir('uploads') ? 'YA' : 'TIDAK') . "<br>";
    echo "Folder writable? " . (is_writable('uploads') ? 'YA' : 'TIDAK') . "<br>";

    // Pindahkan file
    if (move_uploaded_file($tmp, $path)) {
        // Simpan path ke DB
        $id = (int) $id;
        $stmt = $conn->prepare("UPDATE register SET file_path = ? WHERE id = ?");
        $stmt->bind_param("si", $path, $id);
        if ($stmt->execute()) {
            echo "File berhasil diupload. <a href='arsip.php'>Kembali</a>";
        } else {
            echo "Gagal update database: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Gagal memindahkan file ke folder uploads.";
    }

    exit();
}
?>
