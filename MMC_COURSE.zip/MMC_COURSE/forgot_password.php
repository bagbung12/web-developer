<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
date_default_timezone_set('Asia/Jakarta');
require 'vendor/autoload.php';
require 'koneksi.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

    $stmt = $conn->prepare("SELECT * FROM register WHERE email = ? AND is_verified = 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $reset_token = bin2hex(random_bytes(32));
        $expiry = date("Y-m-d H:i:s", strtotime("+1 hour"));

        $update = $conn->prepare("UPDATE register SET reset_token = ?, reset_token_expiry = ? WHERE email = ?");
        $update->bind_param("sss", $reset_token, $expiry, $email);
        $update->execute();

        $mail = new PHPMailer(true);
        try {
            if (!defined('SMTP_HOST') || !defined('SMTP_USER') || !defined('SMTP_PASS') || !defined('SMTP_PORT') || !defined('SENDER_EMAIL') || !defined('SENDER_NAME') || !defined('BASE_URL')) {
                throw new Exception('Konstanta SMTP atau BASE_URL belum didefinisikan.');
            }

            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USER;
            $mail->Password   = SMTP_PASS;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = SMTP_PORT;

            $mail->setFrom(SENDER_EMAIL, SENDER_NAME);
            $mail->addAddress($email, $user['fullname']);
            $mail->isHTML(true);
            $mail->Subject = 'Reset Password - MMC Course';
            $mail->Body    = "
                Halo {$user['fullname']},<br><br>
                Silakan klik link berikut untuk reset password:<br>
                <a href='" . BASE_URL . "/MMC_COURSE/reset_password.php?token=$reset_token'>Reset Password</a><br><br>
                Link ini akan kedaluwarsa dalam 1 jam.<br><br>
                Salam,<br>Tim MMC Course
            ";
            $mail->send();

            $_SESSION['message'] = "Link reset password telah dikirim ke email Anda!";
            header("Location: login2.php");
            exit();
        } catch (Exception $e) {
            $_SESSION['error'] = "Gagal mengirim email: " . $mail->ErrorInfo;
            header("Location: forgot_password.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Email tidak ditemukan atau belum diverifikasi!";
        header("Location: forgot_password.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Lupa Password</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" href="mmm.png">
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="min-height: 100vh;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow-sm">
          <div class="card-body">
            <h4 class="card-title text-center mb-4">Lupa Password</h4>

            <?php if (isset($_SESSION['error'])): ?>
              <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php elseif (isset($_SESSION['message'])): ?>
              <div class="alert alert-success"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
            <?php endif; ?>

            <form method="POST">
              <div class="mb-3">
                <label for="email" class="form-label">Masukkan Email Anda</label>
                <input type="email" name="email" class="form-control" id="email" required>
              </div>
              <button type="submit" class="btn btn-primary w-100">Kirim Link Reset</button>
            </form>

            <div class="text-center mt-3">
              <a href="login2.php" class="text-decoration-none">&larr; Kembali ke Login</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
