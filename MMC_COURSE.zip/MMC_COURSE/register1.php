<?php
session_start();
require 'koneksi.php'; // Pastikan file koneksi.php ada dan benar

// Tentukan halaman saat ini untuk active link di navbar
$current_page = basename($_SERVER['PHP_SELF']); // Ini akan menjadi 'register1.php'
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register Page - MMC COURSE</title>
    <link rel="icon" type="image/png" href="mmm.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding-top: 70px; /* Space for fixed navbar */
            background: url('download.jpeg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Poppins', sans-serif; /* Menggunakan Poppins */
        }

        /* Navbar Styling (Consistent) */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030;
            position: fixed; /* Make navbar fixed */
            top: 0;
            width: 100%;
        }
        .navbar-brand img {
            height: 35px; /* Consistent size */
            margin-right: 8px; /* Adjusted margin */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd;
        }

        /* Register Form Specific Styles (similar to login form) */
        .input {
            max-width: 420px; /* Slightly wider than login for more fields */
            margin: 50px auto; /* Adjust margin-top for fixed navbar */
            background: rgba(0, 0, 0, 0.7); /* Consistent semi-transparent dark background */
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.3);
            color: white;
        }

        .input h1 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 28px;
            color: #ffffff;
            font-weight: 700;
        }

        .box-input {
            position: relative;
            margin-bottom: 20px;
        }

        .box-input i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #ccc;
            z-index: 2;
        }

        .box-input input,
        .box-input select {
            width: 100%;
            padding: 12px 45px 12px 45px; /* Adjusted padding for icons */
            border-radius: 8px;
            border: 1px solid #ddd;
            outline: none;
            background-color: #ffffff;
            color: #333;
            font-size: 16px;
        }
        .box-input input::placeholder {
            color: #999;
        }
        /* Style for select element */
        .box-input select {
            appearance: none; /* Remove default arrow */
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 0.65em 0.65em;
        }


        .toggle-password {
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            cursor: pointer;
            z-index: 3;
            color: #888;
        }

        .btn-input {
            width: 100%;
            padding: 12px;
            background-color: #0d6efd; /* Consistent primary blue */
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            font-size: 18px;
        }

        .btn-input:hover {
            background-color: #0b5ed7;
            transform: translateY(-2px);
            color: #fff;
        }

        .bottom {
            text-align: center;
            margin-top: 25px;
        }

        .bottom p {
            margin-bottom: 8px;
            font-size: 0.95rem;
        }

        .bottom a {
            text-decoration: none;
            color: #00ffff; /* Consistent link color */
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .bottom a:hover {
            color: #00d0d0;
        }

        @media (max-width: 768px) {
            .input {
                margin: 30px auto;
                padding: 20px;
            }

            .input h1 {
                font-size: 22px;
            }
            .navbar-brand img {
                height: 30px;
            }
        }
    </style>
</head>

<body>

    <div class="container-fluid px-0">

        <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
            <div class="container">
                <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                    <img src="mmm.png" alt="MMC Logo" class="me-2">
                    MMC COURSE
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav gap-2">
                        <li class="nav-item">
                            <a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $current_page == 'login2.php' ? 'active' : '' ?>" href="login2.php">LOGIN</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="input">
            <h1>REGISTER</h1>
            <form action="register.php" method="POST">
                <div class="box-input">
                    <i class="fas fa-user"></i>
                    <input type="text" name="fullname" placeholder="Full Name" required />
                </div>

                <div class="box-input">
                    <i class="fas fa-address-book"></i>
                    <input type="text" name="username" placeholder="Username" required />
                </div>

                <div class="box-input">
                    <i class="fas fa-graduation-cap"></i>
                    <select name="course" class="form-select" required>
                        <option value="" disabled selected>Pilih Course</option>
                        <option value="english + toefl">English + TOEFL</option>
                        <option value="english">English</option>
                        <option value="toefl">TOEFL</option>
                        <option value="mandarin">Mandarin</option>
                        <option value="jepang">Jepang</option>
                        <option value="computer">Computer</option>
                        <option value="francis">Francis</option>
                    </select>
                </div>

                <div class="box-input">
                    <i class="fas fa-envelope-open-text"></i>
                    <input type="email" name="email" placeholder="Email" required />
                </div>

                <div class="box-input">
                    <i class="fas fa-phone-alt"></i>
                    <input type="text" name="no_hp" placeholder="No. HP" required />
                </div>

                <div class="box-input">
                    <i class="fas fa-user-friends"></i>
                    <select name="tipe_no_hp" class="form-select" required>
                        <option value="" disabled selected>Nomor HP milik siapa?</option>
                        <option value="sendiri">Milik Sendiri</option>
                        <option value="ortu">Milik Orang Tua</option>
                    </select>
                </div>

                <div class="box-input">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="password" placeholder="Password" required />
                    <span toggle="#password" class="fas fa-eye toggle-password"></span>
                </div>

                <button type="submit" name="register" class="btn-input">Register</button>

                <div class="bottom">
                    <p>Sudah punya akun? <a href="login2.php">Login disini</a></p>
                </div>
            </form>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const togglePassword = document.querySelector(".toggle-password");
        const password = document.querySelector("#password");

        togglePassword.addEventListener("click", function () {
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);
            this.classList.toggle("fa-eye-slash");
        });
    </script>

</body>
</html>