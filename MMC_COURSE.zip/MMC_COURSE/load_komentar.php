<?php
require 'koneksi.php';

$result = mysqli_query($conn, "SELECT * FROM komentar ORDER BY waktu DESC");

while ($row = mysqli_fetch_assoc($result)) {
    $email = htmlspecialchars($row['email']);
    $komentar = nl2br(htmlspecialchars($row['komentar']));
    $waktu = date("Y-m-d H:i:s", strtotime($row['waktu']));
    $like = $row['like_count'];
    $dislike = $row['dislike_count'];
    $id = $row['id'];

    echo "<div class='komentar-box'>";
    echo "<strong>$email</strong><br>";
    echo "<p>$komentar</p>";
    echo "<small>$waktu</small><br>";
    echo "<button class='btn btn-sm btn-outline-success me-2' onclick='likeKomentar($id)'>👍 $like</button>";
    echo "<button class='btn btn-sm btn-outline-danger' onclick='dislikeKomentar($id)'>👎 $dislike</button>";
    echo "</div>";
}
?>
