<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'koneksi.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login2.php');
    exit();
}

// Pencarian (untuk pagination saja, karena pencarian real-time pakai JS)
$per_page_register = 10;
$page_register = isset($_GET['page_register']) ? (int)$_GET['page_register'] : 1;
$start_register = ($page_register - 1) * $per_page_register;
$total_query_register = mysqli_query($conn, "SELECT COUNT(*) AS total FROM register WHERE role = 'user'");
$total_data_register = mysqli_fetch_assoc($total_query_register)['total'];
$total_pages_register = ceil($total_data_register / $per_page_register);

$result_komentar = mysqli_query($conn, "SELECT * FROM komentar ORDER BY waktu DESC LIMIT 10");
$rating_chart = mysqli_query($conn, "SELECT rate, COUNT(*) as total FROM rating GROUP BY rate ORDER BY rate DESC");
$rating_data = [];
while ($row = mysqli_fetch_assoc($rating_chart)) {
    $rating_data[] = $row;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="mmm.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #212529;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .card {
            border-radius: 0.75rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.08);
            border: none;
        }

        .card-header {
            border-top-left-radius: 0.75rem;
            border-top-right-radius: 0.75rem;
            padding: 1rem 1.5rem;
            background-color: #0d6efd;
            color: white;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header h5 {
            margin: 0;
            font-size: 1.25rem;
        }

        .card-header .btn {
            padding: 0.4rem 1rem;
            font-size: 0.85rem;
            border-radius: 0.5rem;
            transition: all 0.2s ease-in-out;
        }

        .card-header .btn:hover {
            opacity: 0.8;
            transform: translateY(-1px);
        }

        .gap-2 {
            gap: 0.75rem !important;
        }

        .form-control, .form-select {
            border-radius: 0.5rem;
            border-color: #ced4da;
        }

        .table {
            margin-top: 1rem;
            border-radius: 0.5rem;
            overflow: hidden;
        }

        .table thead th {
            background-color: #e9ecef;
            vertical-align: middle;
            padding: 0.75rem 1rem;
        }

        .table tbody td {
            vertical-align: middle;
            padding: 0.75rem 1rem;
        }

        .badge {
            padding: 0.4em 0.7em;
            font-size: 0.8em;
            border-radius: 0.35rem;
        }

        .btn-sm {
            padding: 0.35rem 0.75rem;
            font-size: 0.8rem;
        }

        .navbar {
            border-radius: 0 0 0.75rem 0.75rem;
            box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, 0.05);
        }

        .container {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }

        .filter-row .col-md-4 {
            /* display: flex; Align items and gap are better for direct children */
            /* align-items: center; */
            /* gap: 0.5rem; */
        }
        .filter-row .col-md-4 .form-control,
        .filter-row .col-md-4 .form-select {
            width: 100%; /* Ensure inputs take full width of their column */
        }

        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
            }
            .card-header .d-flex {
                flex-wrap: wrap;
            }
            .filter-row .col-md-4 {
                margin-bottom: 1rem; /* Add some space between filter elements on small screens */
            }
            .d-flex.justify-content-end.gap-2.mt-3 {
                flex-direction: column; /* Stack buttons vertically on small screens */
                align-items: stretch; /* Make buttons fill width */
            }
            .d-flex.justify-content-end.gap-2.mt-3 button {
                width: 100%; /* Make buttons full width */
                margin-bottom: 0.5rem; /* Add space between stacked buttons */
            }
            .d-flex.justify-content-end.gap-2.mt-3 button:last-child {
                margin-bottom: 0;
            }
        }

        @media print {
            form,
            .btn,
            .form-control,
            .form-select,
            .no-print,
            .no-print * {
                display: none !important;
            }

            .card-header,
            .card-body,
            table {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body class="bg-light text-dark">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">
            <i class="fas fa-tachometer-alt me-2"></i> Dashboard Admin - <?= htmlspecialchars($_SESSION['user']['email'] ?? '') ?>
        </span>
        <a href="logout.php" class="btn btn-danger btn-sm"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
    </div>
</nav>

<div class="container">
    <div class="card mb-4" id="register-section">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Manajemen Pendaftar (User)</h5>
            <div class="d-flex gap-2">
                <a href="export_register_excel.php" class="btn btn-outline-light btn-sm"><i class="fas fa-file-excel me-1"></i> Download Excel</a>
                <button onclick="printSection('register-section')" class="btn btn-outline-light btn-sm"><i class="fas fa-print me-1"></i> Print</button>
                <a href="arsip.php" class="btn btn-outline-light btn-sm"><i class="fas fa-archive me-1"></i> Arsip</a>
            </div>
        </div>

        <div class="card-body">
            </i>Daftar User Terdaftar</h6>
                <div class="row mb-3 filter-row">
                    <div class="col-md-4">
                        <input type="text" id="search-register" class="form-control" placeholder="Cari Nama / Email...">
                    </div>
                    <div class="col-md-4">
                        <select id="filter-course" class="form-select">
                            <option value="">Semua Course</option>
                            <?php
                                $courses = mysqli_query($conn, "SELECT DISTINCT course FROM register WHERE role = 'user' ORDER BY course ASC");
                                while ($c = mysqli_fetch_assoc($courses)) {
                                    echo '<option value="' . htmlspecialchars($c['course']) . '">' . htmlspecialchars($c['course']) . '</option>';
                                }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="date" id="filter-date" class="form-control">
                    </div>
                </div>

                <div class="table-responsive"> <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th><input type="checkbox" id="checkAll"></th>
                                <th>Fullname</th>
                                <th>Username</th>
                                <th>Course</th>
                                <th>Email</th>
                                <th>Tanggal</th>
                                <th>NO_HP</th>
                                <th>TIPE_NO_HP</th>
                                <th>Status Promo</th>
                                <th class="no-print">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="register-body">
                            <?php
                                $query = mysqli_query($conn, "SELECT * FROM register WHERE role = 'user' ORDER BY id DESC LIMIT $start_register, $per_page_register");
                                while ($row = mysqli_fetch_assoc($query)) {
                            ?>
                            <tr>
                                <td><input type="checkbox" name="selected_users[]" value="<?= $row['id'] ?>" form="userActionForm"></td>
                                <td><?= htmlspecialchars($row['fullname']) ?></td>
                                <td><?= htmlspecialchars($row['username']) ?></td>
                                <td><?= htmlspecialchars($row['course']) ?></td>
                                <td><?= htmlspecialchars($row['email']) ?></td>
                                <td><?= htmlspecialchars($row['tanggal']) ?></td>
                                <td><?= !empty($row['no_hp']) ? htmlspecialchars($row['no_hp']) : '<span class="text-danger">Kosong</span>' ?></td>
                                <td>
                                    <?php
                                        if (isset($row['tipe_no_hp'])) {
                                            echo htmlspecialchars($row['tipe_no_hp']);
                                        } else {
                                            echo '<span class="text-danger">Kolom tidak ditemukan</span>';
                                        }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        if ($row['status_promo'] === 'sudah') {
                                            echo '<span class="badge bg-success">Sudah Dipromosi</span>';
                                        } else {
                                            echo '<span class="badge bg-secondary">Belum Dipromosi</span>';
                                        }
                                    ?>
                                </td>
                                <td class="no-print">
                                    <form action="reset_promo.php" method="POST" style="display:inline;" onsubmit="return confirm('Reset status promo user ini?')">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <button type="submit" class="btn btn-outline-secondary btn-sm"><i class="fas fa-redo-alt"></i> Reset Promo</button>
                                    </form>
                                    <a href="edit_register.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm ms-1"><i class="fas fa-edit"></i> Edit</a>
                                    <form action="hapus_register.php" method="POST" style="display:inline;" onsubmit="return confirm('Yakin ingin menghapus?')">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <button type="submit" class="btn btn-danger btn-sm ms-1"><i class="fas fa-trash-alt"></i> Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div> <div class="d-flex justify-content-end gap-2 mt-3">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#sendPromoModal"><i class="fas fa-paper-plane me-1"></i> Kirim Promo ke Terpilih</button>
                </div>
            </form>
            </div>
    </div>

    <div class="modal fade" id="sendPromoModal" tabindex="-1" aria-labelledby="sendPromoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="sendPromoModalLabel">Kirim Promo ke User Terpilih</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="kirim_promo.php" id="modalPromoForm" enctype="multipart/form-data">
                    <div class="modal-body">
                        <p class="text-muted">Anda akan mengirim promo ke user yang telah Anda centang di tabel.</p>
                        <div class="mb-3">
                            <label for="modalJudul" class="form-label">Judul Promo</label>
                            <input type="text" name="judul" id="modalJudul" class="form-control" placeholder="Masukkan judul promo..." required>
                        </div>
                        <div class="mb-3">
                            <label for="modalPesan" class="form-label">Isi Pesan Promo</label>
                            <textarea name="pesan" id="modalPesan" class="form-control" rows="5" placeholder="Tulis pesan promo di sini..." required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="modalAttachment" class="form-label">Lampirkan File (Opsional)</label>
                            <input type="file" name="attachment" id="modalAttachment" class="form-control">
                            <small class="form-text text-muted">Max. ukuran file 2MB. Format yang diizinkan: JPG, PNG, PDF.</small>
                        </div>
                        <input type="hidden" name="selected_users_ids" id="selectedUserIdsInput">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane me-1"></i> Kirim Promo Sekarang</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Data Komentar</h5>
            <div class="d-flex gap-2">
                <button onclick="printSection('komentar-section')" class="btn btn-outline-light btn-sm"><i class="fas fa-print me-1"></i> Print</button>
            </div>
        </div>

        <div class="card-body" id="komentar-section">
            <input type="text" id="search-komentar" class="form-control mb-2" placeholder="Cari Komentar...">
            <div class="table-responsive"> <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>Komentar</th>
                            <th>Waktu</th>
                            <th class="no-print">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="komentar-body">
                        <?php while ($row = mysqli_fetch_assoc($result_komentar)) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= htmlspecialchars($row['komentar']) ?></td>
                            <td><?= htmlspecialchars($row['waktu']) ?></td>
                            <td class="no-print">
                                <form action="hapus_komentar.php" method="POST" onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                    <input type="hidden" name="id" value="<?= htmlspecialchars($row['id']) ?>">
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i> Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div> </div>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0">Grafik Kepuasan (Rating Bintang)</h5>
        </div>
        <div class="card-body">
            <canvas id="ratingChart" height="100"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function printSection(id) {
        const originalContent = document.body.innerHTML;
        const printContent = document.getElementById(id).innerHTML;
        document.body.innerHTML = printContent;
        window.print();
        document.body.innerHTML = originalContent;
        location.reload();
    }

    const ratingData = <?= json_encode($rating_data); ?>;
    const labels = ratingData.map(r => `${r.rate} ★`);
    const data = ratingData.map(r => r.total);

    new Chart(document.getElementById('ratingChart'), {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Jumlah Rating',
                data,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)', // 1 bintang
                    'rgba(255, 159, 64, 0.6)', // 2 bintang
                    'rgba(255, 205, 86, 0.6)', // 3 bintang
                    'rgba(75, 192, 192, 0.6)', // 4 bintang
                    'rgba(54, 162, 235, 0.6)'  // 5 bintang
                ].slice(0, labels.length).reverse(),
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(255, 205, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(54, 162, 235, 1)'
                ].slice(0, labels.length).reverse(),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, precision: 0 },
                    title: {
                        display: true,
                        text: 'Jumlah Rating'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Rating Bintang'
                    }
                }
            }
        }
    });

    const regInput = document.getElementById("search-register");
    const regBody = document.getElementById("register-body");
    const filterCourse = document.getElementById("filter-course");
    const filterDate = document.getElementById("filter-date");

    function fetchRegisterData() {
        const q = regInput.value;
        const course = filterCourse.value;
        const date = filterDate.value;

        fetch(`search_register.php?q=${encodeURIComponent(q)}&course=${encodeURIComponent(course)}&tanggal=${encodeURIComponent(date)}`)
            .then(res => res.text())
            .then(data => regBody.innerHTML = data);
    }

    regInput.addEventListener("keyup", fetchRegisterData);
    filterCourse.addEventListener("change", fetchRegisterData);
    filterDate.addEventListener("change", fetchRegisterData);

    // Initial fetch to load data when page loads
    fetchRegisterData();


    document.getElementById('checkAll').addEventListener('click', function () {
        const checkboxes = document.querySelectorAll('#register-body input[name="selected_users[]"]');
        checkboxes.forEach(cb => cb.checked = this.checked);
    });

    // Mengisi hidden input di modal saat modal ditampilkan
    document.getElementById('sendPromoModal').addEventListener('show.bs.modal', function (event) {
        const selectedCheckboxes = document.querySelectorAll('#register-body input[name="selected_users[]"]:checked');
        const selectedIds = Array.from(selectedCheckboxes).map(cb => cb.value);

        // Jika tidak ada user yang dipilih, berikan peringatan
        if (selectedIds.length === 0) {
            alert('Mohon pilih setidaknya satu user untuk dikirimi promo.');
            // Mencegah modal terbuka jika tidak ada pilihan
            return event.preventDefault();
        }
        document.getElementById('selectedUserIdsInput').value = selectedIds.join(',');
    });
</script>
</body>
</html>