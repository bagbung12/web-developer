<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'koneksi.php';
session_start();

function sendmail_verify($email, $verification_code){
    require 'vendor/autoload.php';
    $mail = new PHPMailer(true);

    try {
        // Pengaturan SMTP untuk Gmail (atau layanan lain seperti SendGrid, Mailgun)
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Host SMTP Gmail
        $mail->SMTPAuth   = true;
        $mail->Username   = 'emailanda@gmail.com'; // Ganti dengan email Gmail Anda
        $mail->Password   = 'APLIKASI_PASSWORD_ANDA';    // Ganti dengan "App Password" Gmail
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Gunakan ENCRYPTION_SMTPS untuk port 465
        $mail->Port       = 465; // Port SMTP untuk SMTPS

        // Jika Anda ingin menggunakan port 587 (TLS), gunakan ini:
        // $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        // $mail->Port       = 587;

        $mail->setFrom('emailanda@gmail.com', 'MMC_COURSE'); // Ganti dengan email Gmail Anda
        $mail->addAddress($email);
        $mail->addReplyTo('emailanda@gmail.com', 'MMC Course'); // Ganti dengan email Gmail Anda

        $mail->isHTML(true);
        // Link verifikasi tetap menggunakan URL lokal atau placeholder jika belum di-deploy
        $verification_link = "http://localhost/nama_folder_proyek_anda/verify.php?code=$verification_code"; // Ganti dengan path lokal Anda
        $email_template = "
            <h2>Kamu telah melakukan pendaftaran akun MMC_COURSE</h2>
            <h4>Verifikasi emailmu agar dapat login, Klik tautan berikut !</h4>
            <a href='$verification_link'>[ Klik disini ]</a>
        ";
        $mail->Subject = 'Verifikasi Akun MMC Course (Lokal)';
        $mail->Body    = $email_template;

        $mail->send();
        echo 'Email verifikasi berhasil dikirim';
    } catch (Exception $e) {
        echo "Gagal mengirim email. Mailer Error: {$mail->ErrorInfo}";
    }
}

// Sisa kode register Anda tetap sama
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $confirm_password = $_POST['confirm_password'];
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $course = $_POST['course'];
    $no_hp = $_POST['no_hp'];
    $tipe_no_hp = $_POST['tipe_no_hp'];

    // Gunakan koneksi dari koneksi.php
    $query_check_email = "SELECT * FROM register WHERE email = '$email'";
    $sql_check_email = mysqli_query($conn, $query_check_email);
    $result_check_email = mysqli_fetch_assoc($sql_check_email);

    $verification_code = md5(rand());

    if ($result_check_email){
        $_SESSION['log'] = "Email sudah digunakan !";
        header('location: register1.php');
        exit(); // Penting: tambahkan exit setelah header redirect
    } else {
        $query_insert = "INSERT INTO register ( fullname, email, password, no_hp, tipe_no_hp, verification_code, is_verified, username, role, course) 
            VALUES ( '$fullname', '$email', '$password', '$no_hp', '$tipe_no_hp', '$verification_code', '0', '$username', 'user', '$course')";
        
        if($conn->query($query_insert) === TRUE){
            sendmail_verify($email, $verification_code);
            echo"
             <script> 
             alert('Akun berhasil dibuat, silakan verifikasi email terlebih dahulu !');
             window.location.href = 'login2.php';
             </script>";
        } else {
            echo "Error: " . $query_insert . "<br>" . $conn->error;
        }
    }
    $conn->close();
}
?>