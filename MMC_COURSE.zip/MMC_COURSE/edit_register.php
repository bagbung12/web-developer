<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login2.php');
    exit();
}

// ✅ Ubah: gunakan id, bukan email
if (!isset($_GET['id'])) {
    echo "ID tidak ditemukan.";
    exit();
}

$id = (int)$_GET['id']; // Amankan input

$stmt = $conn->prepare("SELECT * FROM register WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Data tidak ditemukan.";
    exit();
}

$data = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $course = $_POST['course'];
    $no_hp = $_POST['no_hp'];

    // ✅ Ubah query update: pakai id sebagai WHERE
    $update = $conn->prepare("UPDATE register SET fullname=?, username=?, no_hp=?, course=? WHERE id=?");
    $update->bind_param("ssssi", $fullname, $username, $no_hp, $course, $id);

    if ($update->execute()) {
        header("Location: dashboard.php?edit=success");
        exit();
    } else {
        $error = "Gagal memperbarui data.";
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card">
        <div class="card-header bg-warning">
            <h5 class="mb-0">Edit Data Register</h5>
        </div>
        <div class="card-body">
            <?php if (isset($error)) : ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Fullname</label>
                    <input type="text" name="fullname" class="form-control" value="<?= htmlspecialchars($data['fullname']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($data['username']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Course</label>
                    <input type="text" name="course" class="form-control" value="<?= htmlspecialchars($data['course']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">no_hp</label>
                    <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($data['no_hp']) ?>" required>
                </div>
                
                <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
