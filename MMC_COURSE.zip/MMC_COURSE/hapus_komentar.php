<?php
require 'koneksi.php';

if (isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $query = "DELETE FROM komentar WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: dashboard.php");
    } else {
        echo "Gagal hapus komentar: " . mysqli_error($conn);
    }
} else {
    echo "Permintaan tidak valid atau ID tidak dikirim.";
}
?>
