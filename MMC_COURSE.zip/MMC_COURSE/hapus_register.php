<?php
require 'koneksi.php';
session_start();

// Amankan ID
$id = $_POST['id'] ?? 0;
$id = (int)$id;

if ($id <= 0) {
    echo "ID tidak valid.";
    exit();
}

$query = "DELETE FROM register WHERE id = $id";

if (mysqli_query($conn, $query)) {
    header("Location: dashboard.php");
    exit();
} else {
    echo "Gagal hapus data: " . mysqli_error($conn);
}
?>
