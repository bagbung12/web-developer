<?php
session_start();
require 'koneksi.php';

// Inisialisasi variabel untuk keamanan dan default
$username = 'PROFIL';
$id_user = 0;
$notif_pesan = '';
$ada_notif = false;
$user_role = '';

// Cek apakah sesi user ada dan atur variabel terkait
if (isset($_SESSION['user'])) {
    $username = htmlspecialchars($_SESSION['user']['username'] ?? 'PROFIL');
    $id_user = (int)($_SESSION['user']['id'] ?? 0);
    $user_role = $_SESSION['user']['role'] ?? '';
}

// Logika notifikasi hanya untuk peran 'user'
if ($id_user > 0 && $user_role === 'user') {
    $stmt = $conn->prepare("SELECT notif_sertifikat FROM register WHERE id = ?");
    $stmt->bind_param("i", $id_user);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $stmt->close();

    if ($data && $data['notif_sertifikat'] == 1) {
        $notif_pesan = "🎉 Sertifikat kamu telah dikirim ke email.";
        $ada_notif = true;
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>MMC COURSE - HOME</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="icon" href="mmm.png" type="image/png" />

    <style>
        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: url(download.jpeg) no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        main {
            flex: 1;
            padding-top: 70px;
        }

        /* Navbar */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030;
            position: fixed;
            top: 0;
            width: 100%;
        }
        .navbar-brand img {
            height: 35px;
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd;
        }
        /* Dropdown specific styles */
        .navbar-nav .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
            border: none;
        }
        .navbar-nav .dropdown-item {
            color: #333;
            transition: background-color 0.2s ease;
            display: flex; /* Untuk menempatkan teks dan tombol hapus sejajar */
            justify-content: space-between; /* Menjauhkan teks dan tombol hapus */
            align-items: center;
        }
        .navbar-nav .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #0d6efd;
        }
        /* Style untuk tombol hapus notifikasi */
        .delete-notif-btn {
            background: none;
            border: none;
            color: #dc3545; /* Merah untuk ikon hapus */
            font-size: 0.9em;
            cursor: pointer;
            padding: 0 5px;
            margin-left: 10px; /* Jarak dari teks */
            opacity: 0.7;
            transition: opacity 0.2s ease;
        }
        .delete-notif-btn:hover {
            opacity: 1;
        }
        .notif-placeholder {
            padding: 0.5rem 1rem;
            color: #6c757d; /* Warna teks muted */
        }


        /* Hero Section */
        .hero-section {
            text-align: center;
            padding: 120px 20px;
            background: rgba(0,0,0,0.6);
            color: #fff;
            border-radius: 10px;
            margin-top: 20px;
            animation: fadeIn 1s ease-out;
        }
        .hero-section h5 {
            font-size: 1.5rem;
            font-weight: 500;
            color: #FFC107;
            margin-bottom: 10px;
        }
        .hero-section h1 {
            font-size: 3.8rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.7);
            animation: slideInUp 1s ease-out;
        }
        .hero-section p {
            font-size: 1.3rem;
            margin-bottom: 40px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
            animation: slideInUp 1.2s ease-out;
        }
        .btn-cta {
            background-color: #FFC107;
            border: none;
            padding: 14px 40px;
            font-size: 1.2rem;
            border-radius: 50px;
            transition: all 0.3s ease;
            font-weight: 600;
            color: #333;
        }
        .btn-cta:hover {
            background-color: #FFB300;
            transform: scale(1.05) translateY(-3px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.3);
            color: #333;
        }

        /* Course List Section */
        .course-list-section {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-top: 50px;
            text-align: center;
        }
        .course-list-section h2 {
            font-size: 2.2rem;
            font-weight: 700;
            color: #0d6efd;
            margin-bottom: 40px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        }
        .course-list {
            list-style: none;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .course-list li {
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px 25px;
            font-size: 1.1rem;
            font-weight: 500;
            color: #555;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            min-width: 200px;
            justify-content: center;
        }
        .course-list li:hover {
            color: #0d6efd;
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .course-list li i {
            font-size: 1.3rem;
            margin-right: 10px;
            color: #28a745;
        }

        /* Footer */
        footer {
            background: #222;
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: auto;
        }
        footer a {
            color: #FFC107;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }

        /* Alerts (for login success) */
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideInUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2.5rem;
            }
            .hero-section p {
                font-size: 1rem;
            }
            .btn-cta {
                font-size: 1rem;
                padding: 10px 25px;
            }
            .course-list-section h2 {
                font-size: 1.8rem;
            }
            .course-list li {
                font-size: 1rem;
                padding: 10px 15px;
                min-width: unset;
            }
            .navbar-brand img {
                height: 30px;
            }
        }
    </style>
</head>
<body>

<div class="container-fluid px-0">

    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                <img src="mmm.png" alt="MMC Logo" class="me-2">
                MMC COURSE
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav gap-2">
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index1.php">HOME</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'blog.php' ? 'active' : '' ?>" href="blog.php">BLOG</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'service.php' ? 'active' : '' ?>" href="service.php">SERVICE</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'ourprogram.php' ? 'active' : '' ?>" href="ourprogram.php">OUR PROGRAM</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'contact.php' ? 'active' : '' ?>" href="contact.php">CONTACT</a></li>
                    
                    <?php if ($user_role === 'user'): ?>
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link position-relative dropdown-toggle" href="#" id="notifDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell"></i>
                                <?php if ($ada_notif): ?>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="notifBadge">
                                        1
                                        <span class="visually-hidden">unread messages</span>
                                    </span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notifDropdown" id="notifList">
                                <?php if ($ada_notif): ?>
                                    <li id="notifItem_sertifikat">
                                        <a class="dropdown-item text-success" href="#">
                                            <span><?= $notif_pesan ?></span>
                                            <button class="delete-notif-btn" data-notif-type="sertifikat">
                                                <i class="fas fa-times-circle"></i>
                                            </button>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li><span class="dropdown-item text-muted" id="noNotifMessage">Tidak ada notifikasi baru</span></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item dropdown">
                        <a class="btn btn-outline-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i> <?= $username ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['user'])): ?>
                                <li><a class="dropdown-item" href="edit_profil.php"><i class="fas fa-edit me-2"></i>Edit Profil</a></li>
                                <li><a class="dropdown-item" href="ganti_password.php"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="login2.php"><i class="fas fa-sign-in-alt me-2"></i>Login</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container py-4">
        <?php
        if (isset($_SESSION['login_success']) && $_SESSION['login_success'] === true):
        ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Selamat datang, <strong><?= htmlspecialchars($_SESSION['user']['username'] ?? 'Pengguna') ?></strong>! Anda berhasil login.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php
            unset($_SESSION['login_success']);
            ?>
        <?php endif; ?>

        <section class="hero-section">
            <?php if (isset($_SESSION['user']['username'])): ?>
                <h5>Halo, <?= htmlspecialchars($_SESSION['user']['username']) ?>!</h5>
            <?php else: ?>
                <h5>Selamat Datang!</h5>
            <?php endif; ?>
            <h1>Tingkatkan Skillmu Bersama MMC COURSE!</h1>
            <p>Bergabunglah dengan ribuan siswa yang telah berhasil meraih impian mereka. Kami menyediakan kursus berkualitas tinggi dengan pengajar ahli.</p>
            <a href="ourprogram.php#ourprogram-form" class="btn btn-cta">Pilih Jadwal Belajar</a>
        </section>

        <section class="course-list-section">
            <h2>MMC COURSE MENYEDIAKAN KURSUS:</h2>
            <ul class="course-list">
                <li><i class="fas fa-check-circle"></i> English</li>
                <li><i class="fas fa-check-circle"></i> Japanese</li>
                <li><i class="fas fa-check-circle"></i> Mandarin</li>
                <li><i class="fas fa-check-circle"></i> French</li>
                <li><i class="fas fa-check-circle"></i> Computer</li>
            </ul>
        </section>
    </main>

    <footer class="text-center">
        <div class="container">
            <p>&copy; <?= date("Y") ?> MMC Course. All rights reserved.</p>
            <div class="social-icons">
                <p>Ikuti kami:</p>
                <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
 
<script>
    const notifBadge = document.getElementById('notifBadge'); // Badge angka 1
    const notifList = document.getElementById('notifList'); // Container ul dropdown notifikasi
    const notifItemSertifikat = document.getElementById('notifItem_sertifikat'); // Item notifikasi sertifikat
    const notifDropdown = document.getElementById('notifDropdown'); // Elemen <a> yang diklik untuk membuka dropdown

    // Fungsi untuk menampilkan/menyembunyikan pesan "Tidak ada notifikasi baru"
    function toggleNoNotifMessage() {
        if (!notifList) return;

        const isSertifNotifPresent = document.getElementById('notifItem_sertifikat') !== null;
        let noNotifMessage = document.getElementById('noNotifMessage');

        if (!isSertifNotifPresent) {
            if (!noNotifMessage) {
                const li = document.createElement('li');
                li.innerHTML = '<span class="dropdown-item text-muted" id="noNotifMessage">Tidak ada notifikasi baru</span>';
                notifList.appendChild(li);
            }
        } else {
            if (noNotifMessage) {
                noNotifMessage.parentElement.remove();
            }
        }
    }

    // Event listener untuk tombol hapus notifikasi sertifikat
    if (notifItemSertifikat) {
        const deleteBtn = notifItemSertifikat.querySelector('.delete-notif-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();

                const notifType = this.dataset.notifType;

                fetch('reset_notif.php?type=' + notifType)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok ' + response.statusText);
                        }
                        return response.text();
                    })
                    .then(data => {
                        if (data.trim() === 'ok') {
                            notifItemSertifikat.remove(); // Hapus item notifikasi

                            if (notifBadge) {
                                notifBadge.remove(); // Hapus badge saat notifikasi dihapus
                            }
                            
                            toggleNoNotifMessage(); // Perbarui pesan "Tidak ada notifikasi baru"

                        } else {
                            console.error('Server responded:', data);
                            alert('Gagal menghapus notifikasi. Silakan coba lagi. Pesan server: ' + data);
                        }
                    })
                    .catch(error => {
                        console.error('Error deleting notification:', error);
                        alert('Terjadi kesalahan saat menghapus notifikasi. Silakan cek konsol.');
                    });
            });
        }
    }

    // Event listener untuk saat lonceng notifikasi (dropdown) diklik
    if (notifDropdown) {
        notifDropdown.addEventListener('click', function() {
            if (notifBadge) {
                notifBadge.remove(); 
                fetch('reset_notif.php?type=sertifikat')
                    .then(response => {
                        if (!response.ok) {
                            console.error('Network response was not ok for dropdown click:', response.statusText);
                        }
                        return response.text();
                    })
                    .then(data => {
                        if (data.trim() !== 'ok') {
                            console.error('Server responded with error on dropdown click:', data);
                           
                        }
                       
                    })
                    .catch(error => {
                        console.error('Error resetting notification on dropdown click:', error);
                    });
                // ************ AKHIR PERUBAHAN UTAMA ************
            }
        });
    }

    document.addEventListener('DOMContentLoaded', toggleNoNotifMessage);
</script>
</body>
</html>