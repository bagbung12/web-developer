<?php
session_start();
require 'koneksi.php'; // Sesuaikan path ke file koneksi Anda

header('Content-Type: text/plain'); // Pastikan responsnya adalah plain text

if (isset($_SESSION['user']['id'])) {
    $id_user = (int)$_SESSION['user']['id'];

    // Ambil tipe notifikasi dari parameter GET
    $notif_type = $_GET['type'] ?? '';

    // Hanya reset jika tipe notifikasi adalah 'sertifikat'
    if ($notif_type === 'sertifikat') {
        $stmt = $conn->prepare("UPDATE register SET notif_sertifikat = 0 WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $id_user);
            if ($stmt->execute()) {
                echo 'ok'; // Beri tahu JavaScript bahwa berhasil
            } else {
                echo 'Error executing update: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            echo 'Error preparing statement: ' . $conn->error;
        }
    } else {
        echo 'Invalid notification type.';
    }
} else {
    echo 'User not logged in.';
}

$conn->close();
?>