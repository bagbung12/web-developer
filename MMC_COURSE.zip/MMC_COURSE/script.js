// script.js
const navLinks = document.querySelectorAll('.nav-link');
const currentPage = window.location.pathname.split("/").pop();

navLinks.forEach(link => {
    if (link.getAttribute("href") === currentPage) {
        link.classList.add('active');
    }
});
function redirectToWhatsApp() {
    window.location.href = "https://wa.me/+6282120750960";
    console.log('wa click');
}
let selectedDay = null;
let selectedTime = null;

const days = document.querySelectorAll('.day');
const timeSlots = document.querySelectorAll('.time-slot');
const bookingInfo = document.getElementById('booking-info');

days.forEach(day => {
    day.addEventListener('click', () => {
        days.forEach(d => d.classList.remove('selected'));
        day.classList.add('selected');
        selectedDay = day.dataset.day;
        updateBookingInfo();
    });
});

timeSlots.forEach(timeSlot => {
    timeSlot.addEventListener('click', () => {
        timeSlots.forEach(t => t.classList.remove('selected'));
        timeSlot.classList.add('selected');
        selectedTime = timeSlot.dataset.time;
        updateBookingInfo();
    });
});

function updateBookingInfo() {
    if (selectedDay && selectedTime) {
        bookingInfo.textContent = `Jadwal yang dipilih: ${selectedDay}, ${selectedTime}`;
    } else if (selectedDay) {
        bookingInfo.textContent = `Hari yang dipilih: ${selectedDay}`;
    } else if (selectedTime) {
        bookingInfo.textContent = `Waktu yang dipilih: ${selectedTime}`;
    } else {
        bookingInfo.textContent = '';
    }
}

const instagramButton = document.querySelector('.instagram-button');

if (instagramButton) {
    instagramButton.addEventListener('click', () => {
        console.log('Tombol Instagram diklik!');
    });
}
// Modal preview gambar
document.querySelectorAll('.gallery-img').forEach(img => {
  img.addEventListener('click', () => {
    const modalImg = document.getElementById('modalImage');
    modalImg.src = img.src;
    const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
    imageModal.show();
  });
});

// AJAX kirim komentar
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#komentarForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const komentar = form.komentar.value.trim();
      if (!komentar) return;

      const formData = new FormData(form);
      const res = await fetch('simpan_komentar.php', {
        method: 'POST',
        body: formData
      });

      if (res.ok) {
        const html = await res.text();
        const komentarContainer = document.querySelector('#daftarKomentar');
        komentarContainer.insertAdjacentHTML('beforeend', html);
        form.komentar.value = '';
      } else {
        alert('Gagal mengirim komentar.');
      }
    });
  }
});


