<?php
require_once 'config.php';

$servername = "localhost"; // Untuk koneksi lokal, biasanya ini 'localhost'
$username = "root"; // Username default di XAMPP/WAMP seringkali 'root'
$password = ""; // Password default di XAMPP/WAMP seringkali kosong
$dbname = "mmcdb"; // Ganti dengan nama database yang Anda buat di localhost

// Membuat objek koneksi MySQLi baru
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa apakah koneksi berhasil
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Opsional: Anda bisa menambahkan pesan sukses ini untuk pengujian
// echo "Berhasil terhubung ke database lokal!";

?>