<?php
session_start();
require 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user']) || !isset($_POST['komentar']) || !isset($_POST['rating'])) {
    http_response_code(400);
    exit('Data tidak lengkap!');
}

$email = $_SESSION['user']['email'];
$komentar = htmlspecialchars($_POST['komentar']);
$rating = intval($_POST['rating']);
$waktu = date('Y-m-d H:i:s');

// Simpan komentar
$stmt1 = $conn->prepare("INSERT INTO komentar (email, komentar, waktu, like_count, dislike_count, parent_id) VALUES (?, ?, ?, 0, 0, 0)");
$stmt1->bind_param("sss", $email, $komentar, $waktu);
$success1 = $stmt1->execute();
$stmt1->close();

// Cek apakah user sudah pernah rating
$cek = $conn->prepare("SELECT id FROM rating WHERE email = ?");
$cek->bind_param("s", $email);
$cek->execute();
$cek->store_result();

if ($cek->num_rows > 0) {
    // UPDATE rating
    $stmt2 = $conn->prepare("UPDATE rating SET rate = ?, waktu = NOW() WHERE email = ?");
    $stmt2->bind_param("is", $rating, $email);
} else {
    // INSERT rating baru
    $stmt2 = $conn->prepare("INSERT INTO rating (email, rate) VALUES (?, ?)");
    $stmt2->bind_param("si", $email, $rating);
}
$success2 = $stmt2->execute();
$stmt2->close();
$cek->close();
$conn->close();

if ($success1 && $success2) {
    header("Location: contact.php?status=success");
    exit;
} else {
    header("Location: contact.php?status=error");
    exit;
}
?>
