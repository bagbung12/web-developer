<?php
session_start();
require 'koneksi.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // pastikan path ini sesuai dengan folder PHPMailer-mu

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login2.php");
    exit();
}

$id = $_POST['id'] ?? 0;
$id = (int)$id;

// Ambil data dari database
$stmt = $conn->prepare("SELECT email, fullname, file_path FROM register WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Data tidak ditemukan.";
    exit();
}

$data = $result->fetch_assoc();

if (empty($data['file_path']) || !file_exists($data['file_path'])) {
    echo "File tidak tersedia atau tidak ditemukan.";
    exit();
}

$email_penerima = $data['email'];
$nama_penerima = $data['fullname'];
$file = $data['file_path'];

// Kirim email pakai PHPMailer
$mail = new PHPMailer(true);

try {
    // Server SMTP
    $mail->isSMTP();
    $mail->Host       = 'mmccourse.my.id'; 
    $mail->SMTPAuth   = true;
    $mail->Username   = 'mmccourse@mmccourse.my.id'; 
    $mail->Password   = 'mmcoke123@';    
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Pengirim
    $mail->setFrom('mmccourse@mmccourse.my.id', 'MMC Course'); 

    // Penerima
    $mail->addAddress($email_penerima, $nama_penerima);

    // File lampiran
    $mail->addAttachment($file);

    // Konten Email
    $mail->isHTML(true);
    $mail->Subject = 'File dari MMC Course';
    $mail->Body    = "Halo <strong>$nama_penerima</strong>,<br><br>
    Berikut terlampir file sertifikat dari MMC Course.<br><br>
    Terima kasih.";

        $mail->send();

   
    $conn->query("UPDATE register SET notif_sertifikat = 1 WHERE id = $id");

    echo "Email berhasil dikirim ke $email_penerima. <a href='arsip.php'>Kembali</a>";

} catch (Exception $e) {
    echo "Email gagal dikirim. Error: {$mail->ErrorInfo}";
}
?>
