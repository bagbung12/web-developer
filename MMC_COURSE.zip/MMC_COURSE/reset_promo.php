<?php
ini_set('display_errors', 1);
error_reporting(E_ALL); // Tampilkan semua error
session_start();
require 'koneksi.php'; // Pastikan jalur ke koneksi.php benar

// Periksa apakah user adalah admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login2.php');
    exit();
}

// --- DEBUGGING AREA ---
echo "<h2>Debugging reset_promo.php</h2>";
echo "Metode Request: " . $_SERVER['REQUEST_METHOD'] . "<br>";
echo "Data POST: ";
var_dump($_POST);
echo "<hr>";
// --- END DEBUGGING AREA ---


// Pastikan request adalah POST dan ada ID yang dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = (int)$_POST['id']; // Amankan input ID sebagai integer

    // Query untuk mereset status_promo menjadi 'belum' untuk ID yang dipilih
    // Hapus kondisi 'AND role = "user"' jika tidak diperlukan dan coba tanpa itu dulu
    $query = "UPDATE register SET status_promo = 'belum' WHERE id = $id"; // Hapus AND role = 'user' untuk sementara debugging
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Cek apakah ada baris yang terpengaruh (row_count > 0)
        if (mysqli_affected_rows($conn) > 0) {
            echo "<script>alert('Status promo berhasil direset untuk ID: " . $id . ".'); window.location.href='dashboard.php';</script>";
        } else {
            // Jika tidak ada baris yang terpengaruh, mungkin ID tidak ditemukan atau status sudah 'belum'
            echo "<script>alert('Tidak ada perubahan status promo atau ID " . $id . " tidak ditemukan.'); window.location.href='dashboard.php';</script>";
        }
    } else {
        // Gagal mereset (misalnya, error database)
        echo "<script>alert('Gagal mereset status promo untuk ID " . $id . ": " . mysqli_error($conn) . "'); window.location.href='dashboard.php';</script>";
    }
} else {
    // Jika tidak ada ID atau bukan POST request
    echo "<script>alert('Akses tidak valid atau ID tidak ditemukan.'); window.location.href='dashboard.php';</script>";
}

mysqli_close($conn);
exit(); // Pastikan tidak ada output lain setelah alert/redirect
?>