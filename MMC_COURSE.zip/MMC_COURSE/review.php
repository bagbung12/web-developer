<?php
session_start();
require 'koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login2.php");
    exit();
}

$id = $_GET['id'] ?? 0;
$id = (int)$id;

// Ambil data berdasarkan ID
$stmt = $conn->prepare("SELECT * FROM register WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Data tidak ditemukan.";
    exit();
}

$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Review Pendaftar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mt-4">
    <h3>Review Data Pendaftar</h3>
    <table class="table table-bordered">
      <tr><th>Nama</th><td><?= htmlspecialchars($data['fullname']) ?></td></tr>
      <tr><th>Username</th><td><?= htmlspecialchars($data['username']) ?></td></tr>
      <tr><th>Email</th><td><?= htmlspecialchars($data['email']) ?></td></tr>
      <tr><th>Course</th><td><?= htmlspecialchars($data['course']) ?></td></tr>
      <tr><th>Tanggal</th><td><?= htmlspecialchars($data['tanggal']) ?></td></tr>
      <tr><th>NO HP</th><td><?= htmlspecialchars($data['no_hp']) ?></td></tr>
      <tr><th>Tipe No HP</th><td><?= htmlspecialchars($data['tipe_no_hp']) ?></td></tr>
      <tr><th>File Upload</th>
        <td>
          <?php if (!empty($data['file_path']) && file_exists($data['file_path'])): ?>
            <a href="<?= $data['file_path'] ?>" target="_blank">Lihat File</a>
          <?php else: ?>
            <span class="text-danger">Belum ada file</span>
          <?php endif; ?>
        </td>
      </tr>
    </table>
    <a href="arsip.php" class="btn btn-secondary">Kembali ke Arsip</a>
  </div>
</body>
</html>
