<?php
session_start();
require 'koneksi.php'; // Pastikan file koneksi.php ada dan benar

$username = isset($_SESSION['user']['username']) ? htmlspecialchars($_SESSION['user']['username']) : 'PROFIL';
$current_page = basename($_SERVER['PHP_SELF']); // Ini akan menjadi 'service.php'

$id_user = $_SESSION['user']['id'] ?? 0;
$notif_pesan = '';
$ada_notif = false;


if ($id_user > 0 && isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'user') {
    $cek = mysqli_query($conn, "SELECT notif_sertifikat FROM register WHERE id = $id_user");
    $data = mysqli_fetch_assoc($cek);

    if ($data && $data['notif_sertifikat'] == 1) {
        $notif_pesan = "🎉 Sertifikat kamu telah dikirim ke email.";
        $ada_notif = true;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>MMC COURSE - Layanan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="icon" type="image/png" href="mmm.png">

    <style>
        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', sans-serif; /* Menggunakan Poppins */
            background: url('download.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Main content takes remaining space */
        main {
            flex: 1;
            padding-top: 70px; /* Adjust for fixed navbar height */
        }

        /* Navbar Styling (Consistent with index1.php and blog.php) */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030;
            position: fixed; /* Make navbar fixed */
            top: 0;
            width: 100%;
        }
        .navbar-brand img {
            height: 35px; /* Slightly larger */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd;
        }
        .navbar-nav .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
            border: none;
        }
        .navbar-nav .dropdown-item {
            color: #333;
            transition: background-color 0.2s ease;
        }
        .navbar-nav .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #0d6efd;
        }
        /* Notification bell styling */
        .nav-item .fa-bell {
            color: #0d6efd; /* Blue bell icon */
        }
        .nav-item .badge {
            font-size: 0.75em;
            padding: 0.35em 0.6em;
        }

        /* Section Styling */
        section {
            background-color: rgba(255, 255, 255, 0.95); /* Semi-transparent white background */
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-top: 40px;
            margin-bottom: 40px;
        }
        section h2 {
            font-weight: 700;
            color: #0d6efd; /* Consistent blue color */
            margin-bottom: 30px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }

        /* Card Styling for Courses and Facilities */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden; /* Hide overflow for rounded images */
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        .card-img-top {
            max-height: 200px;
            object-fit: contain; /* Use contain to fit the entire image without cropping */
            padding: 20px; /* Add padding for a cleaner look */
            background-color: #f8f9fa; /* Light background for the image area */
            border-bottom: 1px solid #eee;
        }
        .card-title {
            font-weight: 600;
            margin-bottom: 15px;
            font-size: 1.5rem;
        }
        .card-body ul {
            list-style: none;
            padding: 0;
            margin-top: 15px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        .card-body ul li {
            padding: 5px 0;
            color: #555;
            font-size: 0.95rem;
            display: flex;
            align-items: flex-start; /* Align items to the start for multi-line list items */
        }
        .card-body ul li::before {
            content: "\f00c"; /* Font Awesome check icon */
            font-family: "Font Awesome 6 Free"; /* Make sure to use the correct font-family for Font Awesome 6 */
            font-weight: 900;
            color: #28a745; /* Green checkmark */
            margin-right: 10px;
            font-size: 0.8rem;
            line-height: inherit; /* Inherit line height to align with text */
        }

        /* Specific styles for Facility Cards */
        .facility-card .card-header {
            background-color: #0d6efd;
            color: #fff;
            font-weight: 600;
            padding: 15px;
            font-size: 1.1rem;
            border-bottom: none;
        }
        .facility-card .card-body {
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px; /* Space between images */
            align-items: center;
        }
        .facility-card .card-body img {
            height: 180px; /* Fixed height for facility images */
            width: 100%; /* Make images take full width of their container */
            object-fit: cover; /* Crop to fit, ensuring consistency */
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            transition: transform 0.2s ease;
        }
        .facility-card .card-body img:hover {
            transform: scale(1.03);
        }

        /* Footer (Consistent with index1.php and blog.php) */
        footer {
            background: #222;
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: auto;
        }
        footer a {
            color: #FFC107;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }

        /* Media Queries */
        @media (max-width: 767.98px) { /* Changed from 768px to 767.98px for Bootstrap's exact breakpoint */
            section {
                padding: 30px;
            }
            section h2 {
                font-size: 1.8rem;
            }
            .navbar-brand img {
                height: 30px;
            }
            .card-title {
                font-size: 1.3rem;
            }
            .card-body ul {
                padding-top: 0; /* Remove top padding for smaller screens if list is toggled */
                border-top: none; /* Remove border if list is toggled */
            }
            /* Hide list by default on small screens, show button */
            .card-body ul {
                display: none !important; /* Ensure it's hidden by default on small screens */
            }
            .card-body .btn.d-md-none {
                display: block !important;
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container-fluid px-0">

    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                <img src="mmm.png" alt="MMC Logo" class="me-2">
                MMC COURSE
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav gap-2">
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index1.php">HOME</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'blog.php' ? 'active' : '' ?>" href="blog.php">BLOG</a></li>
                    <li class="nav-item"><a class="nav-link <?= ($current_page == 'service.php' || $current_page == 'service1.php') ? 'active' : '' ?>" href="service.php">SERVICE</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'ourprogram.php' ? 'active' : '' ?>" href="ourprogram.php">OUR PROGRAM</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'contact.php' ? 'active' : '' ?>" href="contact.php">CONTACT</a></li>
                    
                    <?php if (isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'user'): ?>
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link position-relative dropdown-toggle" href="#" id="notifDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell"></i>
                                <?php if ($ada_notif): ?>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        1
                                        <span class="visually-hidden">unread messages</span>
                                    </span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notifDropdown">
                                <?php if ($ada_notif): ?>
                                    <li><span class="dropdown-item text-success"><?= $notif_pesan ?></span></li>
                                <?php else: ?>
                                    <li><span class="dropdown-item text-muted">Tidak ada notifikasi baru</span></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item dropdown">
                        <a class="btn btn-outline-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle me-1"></i> <?= $username ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['user'])): // Cek apakah ada sesi user aktif ?>
                                <li><a class="dropdown-item" href="edit_profil.php"><i class="fas fa-edit me-2"></i>Edit Profil</a></li>
                                <li><a class="dropdown-item" href="ganti_password.php"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="login2.php"><i class="fas fa-sign-in-alt me-2"></i>Login</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container py-5">
        <section>
            <h2 class="text-center mb-4">Program Kursus</h2>
            <div class="row g-4 justify-content-center"> <?php
                $courses = [
                    ['img' => 'eng.png', 'title' => 'English', 'color' => 'primary', 'list' => [
                        'General English','Conversation','Business English & Communication','TOEFL','TOEIC',
                        'English for Job Application & Interview','English for Sales & Marketing','English for Banking & Finance',
                        'English for Secretary','English Export & Import','English for Hotel','English for Tour & Travel',
                        'English for Customer Service','English for Master of Ceremony','English for Medical & Hospital',
                        'English for Telecommunication','English for Technician','English for Children','English for Teenagers','Academic Study Skill'
                    ]],
                    ['img' => 'jepang.png', 'title' => 'Japanese', 'color' => 'danger', 'list' => [
                        'Shokyu (Dasar) I–III','Chukyu (Menengah) I–III','Jokyu (Terampil) I–III',
                        'Kaiwa (Percakapan)','Japanese Language Proficiency Test'
                    ]],
                    ['img' => 'china.png', 'title' => 'Mandarin', 'color' => 'warning', 'list' => [
                        'Chu Ji (Dasar) I–III','Zhong Ji (Menengah) I–II','Gao Ji (Lanjutan) I–II',
                        'Shang Ye Hui Hua (Bisnis)','Komputer berbasis Mandarin'
                    ]],
                    ['img' => 'paris.png', 'title' => 'French', 'color' => 'info', 'list' => [
                        'Vrai debutant (Pemula)','Intermediate','Advance'
                    ]],
                    ['img' => 'komputer.png', 'title' => 'Computer', 'color' => 'success', 'list' => [
                        'Perkantoran','Administrasi Bisnis','Akuntansi','Database','3D Studio Max','Animasi 2D & 3D',
                        'Database Access','Design Grafis','Web Design & Master','AutoCAD'
                    ]]
                ];
                foreach ($courses as $course) {
                    $id = strtolower($course['title']);
                    echo '<div class="col-md-6 col-lg-4 d-flex"> <div class="card h-100 shadow-sm">
                                <img src="'.$course['img'].'" class="card-img-top" alt="'.$course['title'].'">
                                <div class="card-body d-flex flex-column"> <h5 class="card-title text-'.$course['color'].'">'.$course['title'].'</h5>
                                    <button class="btn btn-sm btn-outline-'.$course['color'].' d-md-none mb-3" onclick="toggleList(this, \'list-'.$id.'\')">Tampilkan Program</button>
                                    <ul class="flex-grow-1 small" id="list-'.$id.'">'; // flex-grow-1 makes list take available space
                    foreach ($course['list'] as $item) {
                        echo "<li>$item</li>";
                    }
                    echo        '</ul>
                                </div>
                            </div>
                        </div>';
                }
                ?>
            </div>
        </section>

        <section class="mt-5">
            <h2 class="text-center mb-4">Fasilitas MMC Course</h2>
            <div class="row row-cols-1 row-cols-md-3 g-4">

                <div class="col">
                    <div class="card h-100 facility-card">
                        <div class="card-header">Ruang Kelas</div>
                        <div class="card-body">
                            <img src="kelas1 (1).jpeg" class="img-fluid rounded" alt="Kelas 1">
                            <img src="kelas2.jpeg" class="img-fluid rounded" alt="Kelas 2">
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card h-100 facility-card">
                        <div class="card-header">Ruang Tunggu & Mushola</div>
                        <div class="card-body">
                            <img src="tunggu1.jpeg" class="img-fluid rounded" alt="Ruang Tunggu">
                            <img src="mushola2.jpeg" class="img-fluid rounded" alt="Mushola">
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card h-100 facility-card">
                        <div class="card-header">Lab Komputer</div>
                        <div class="card-body">
                            <img src="lab1.jpeg" class="img-fluid rounded" alt="Lab Komputer 1">
                            <img src="lab2.jpeg" class="img-fluid rounded" alt="Lab Komputer 2">
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </main>

    <footer class="text-center">
        <div class="container">
            <p>&copy; <?= date("Y") ?> MMC Course. All rights reserved.</p>
            <p>Ikuti kami:
                <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram ms-2"></i></a>
            </p>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
 
<script>
    // Script for notification bell
    const notifBell = document.getElementById('notifDropdown');

    notifBell?.addEventListener('click', function () {
        const badge = notifBell.querySelector('.badge');
        if (badge) {
            fetch('reset_notif.php')
                .then(response => response.text())
                .then(data => {
                    if (data.trim() === 'ok') {
                        badge.remove();
                        const dropdownMenu = notifBell.nextElementSibling;
                        if (dropdownMenu) {
                            dropdownMenu.innerHTML = '<li><span class="dropdown-item text-muted">Tidak ada notifikasi baru</span></li>';
                        }
                    }
                })
                .catch(error => console.error('Error resetting notification:', error));
        }
    });

    // Script for toggling course lists on mobile
    function toggleList(button, id) {
        const el = document.getElementById(id);
        if (el.classList.contains('d-none')) {
            el.classList.remove('d-none');
            button.textContent = 'Sembunyikan Program';
        } else {
            el.classList.add('d-none');
            button.textContent = 'Tampilkan Program';
        }
    }

    // Initialize list visibility based on screen size
    document.addEventListener('DOMContentLoaded', function() {
        const courseCards = document.querySelectorAll('.card-body ul');
        courseCards.forEach(ul => {
            const button = ul.previousElementSibling; // Get the button associated with this list
            if (window.innerWidth < 768) { // Bootstrap's md breakpoint
                ul.classList.add('d-none'); // Hide on small screens initially
                if (button && button.classList.contains('d-md-none')) {
                    button.textContent = 'Tampilkan Program'; // Set initial button text
                    button.style.display = 'block'; // Ensure button is visible on small screens
                }
            } else {
                ul.classList.remove('d-none'); // Show on large screens
                if (button && button.classList.contains('d-md-none')) {
                    button.style.display = 'none'; // Hide the button
                }
            }
        });
    });

    // Handle resize events to adjust list visibility
    window.addEventListener('resize', function() {
        const courseCards = document.querySelectorAll('.card-body ul');
        courseCards.forEach(ul => {
            const button = ul.previousElementSibling;
            if (window.innerWidth >= 768) {
                ul.classList.remove('d-none'); // Show on large screens
                if (button && button.classList.contains('d-md-none')) {
                    button.style.display = 'none'; // Hide the button
                }
            } else {
                if (button && button.classList.contains('d-md-none')) {
                    // Only hide if it's currently showing and was originally hidden by JS
                    if (!ul.classList.contains('d-none')) { // If it's currently visible
                       ul.classList.add('d-none'); // Hide it again
                       button.textContent = 'Tampilkan Program'; // Reset button text
                    }
                    button.style.display = 'block'; // Show the button
                }
            }
        });
    });
</script>

</body>
</html>