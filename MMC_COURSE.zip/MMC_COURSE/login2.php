<?php
session_start();
// Halaman ini tidak memerlukan koneksi.php kecuali jika Anda ingin menampilkan pesan error dari database.
// Namun, untuk pesan login error, cukup dari session.

// Tentukan halaman saat ini untuk active link di navbar
$current_page = basename($_SERVER['PHP_SELF']); // Ini akan menjadi 'login2.php'
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login Page - MMC COURSE</title>
    <link rel="icon" type="image/png" href="mmm.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            background: url('download.jpeg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Poppins', sans-serif; /* Menggunakan Poppins */
            margin: 0;
            padding-top: 70px; /* Space for fixed navbar */
        }

        /* Navbar Styling (Consistent) */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background-color: #ffffff;
            z-index: 1030;
            position: fixed; /* Make navbar fixed */
            top: 0;
            width: 100%;
        }
        .navbar-brand img {
            height: 35px; /* Slightly larger */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active { /* Added .active state */
            color: #0d6efd;
        }
        /* No need for dropdown specific styles as there's no dropdown in login page navbar */

        /* Login Form Specific Styles */
        .input {
            max-width: 380px;
            margin: 50px auto; /* Adjust margin-top for fixed navbar */
            background: rgba(0, 0, 0, 0.7); /* Slightly darker for better contrast */
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.3); /* Stronger shadow */
            color: white;
        }

        .input h1 {
            text-align: center;
            margin-bottom: 25px; /* Increased margin */
            font-size: 28px; /* Slightly larger heading */
            color: #ffffff;
            font-weight: 700; /* Bold heading */
        }

        .box-input {
            position: relative;
            margin-bottom: 20px; /* Increased margin */
        }

        .box-input i {
            position: absolute;
            left: 15px; /* Adjusted icon position */
            top: 50%;
            transform: translateY(-50%);
            color: #ccc; /* Lighter icon color */
            z-index: 2;
        }

        .box-input input {
            width: 100%;
            padding: 12px 45px 12px 45px; /* Adjusted padding for icons */
            border-radius: 8px; /* Slightly larger border-radius */
            border: 1px solid #ddd; /* Added a subtle border */
            outline: none;
            background-color: #ffffff; /* White background for input */
            color: #333;
            font-size: 16px; /* Larger font size */
        }
        .box-input input::placeholder {
            color: #999;
        }


        .toggle-password {
            position: absolute;
            top: 50%;
            right: 15px; /* Adjusted toggle icon position */
            transform: translateY(-50%);
            cursor: pointer;
            z-index: 3;
            color: #888;
        }

        .btn-input {
            width: 100%;
            padding: 12px; /* Adjusted padding */
            background-color: #0d6efd; /* Consistent primary blue */
            color: #fff; /* White text for button */
            font-weight: bold;
            border: none;
            border-radius: 8px; /* Consistent border-radius */
            transition: background-color 0.3s ease, transform 0.2s ease;
            font-size: 18px; /* Larger button text */
        }

        .btn-input:hover {
            background-color: #0b5ed7; /* Darker blue on hover */
            transform: translateY(-2px); /* Slight lift effect */
            color: #fff; /* Ensure text remains white */
        }

        .bottom {
            text-align: center;
            margin-top: 25px; /* Increased margin */
        }

        .bottom p {
            margin-bottom: 8px; /* Space between lines */
            font-size: 0.95rem; /* Slightly larger text */
        }

        .bottom a {
            text-decoration: none;
            color: #00ffff; /* Your chosen link color */
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .bottom a:hover {
            color: #00d0d0; /* Darker on hover */
        }
        
        .bottom p.text-muted {
        color: #ffffff !important; 
}

        @media (max-width: 768px) {
            .input {
                margin: 30px auto; /* Adjust margin for smaller screens */
                padding: 20px;
            }

            .input h1 {
                font-size: 22px;
            }
            .navbar-brand img {
                height: 30px; /* Smaller logo on mobile */
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid px-0">

        <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
            <div class="container">
                <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                    <img src="mmm.png" alt="MMC Logo" class="me-2">
                    MMC COURSE
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav gap-2">
                        <li class="nav-item">
                            <a class="nav-link <?= $current_page == 'index1.php' ? 'active' : '' ?>" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $current_page == 'login2.php' ? 'active' : '' ?>" href="login2.php">LOGIN</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="input">
            <h1>LOGIN</h1>

            <?php if (isset($_SESSION['login_error'])): ?>
                <p style="color:red; text-align:center; font-size: 0.9rem; margin-bottom: 15px;"><?= $_SESSION['login_error']; unset($_SESSION['login_error']); ?></p>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="box-input">
                    <i class="fas fa-envelope-open-text"></i>
                    <input type="email" name="email" placeholder="Email" required />
                </div>

                <div class="box-input">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="password" placeholder="Password" required />
                    <span toggle="#password" class="fas fa-eye toggle-password"></span>
                </div>

                <button type="submit" name="login" class="btn-input">Login</button>

                <div class="bottom">
                    <p>Belum punya akun? <a href="register1.php">Register disini</a></p>
                    <p><a href="forgot_password.php">Lupa Password?</a></p>
                    <p class="text-muted mt-3">© 2025 MMC COURSE</p>
                    <p class="text-muted mt-3">© Website Developer By Bagas Muhamad Febrian</p>
                </div>
            </form>
        </div>

    </div><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const togglePassword = document.querySelector(".toggle-password");
        const password = document.querySelector("#password");

        togglePassword.addEventListener("click", function () {
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);
            this.classList.toggle("fa-eye-slash");
        });
    </script>
</body>
</html>