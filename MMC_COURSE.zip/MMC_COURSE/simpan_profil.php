<?php
session_start();
require 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];

    $email_lama = $_SESSION['user']['email'];

    $query = "UPDATE register SET fullname=?, username=?, email=? WHERE email=?";
    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $fullname, $username, $email, $email_lama);

        if (mysqli_stmt_execute($stmt)) {
            // Update session
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['username'] = $username;

            header("Location: index1.php");
            exit();
        } else {
            echo "Gagal update profil: " . mysqli_stmt_error($stmt);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal menyiapkan statement: " . mysqli_error($conn);
    }
}
?>
