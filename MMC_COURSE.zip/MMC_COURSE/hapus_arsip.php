<?php
session_start();
require 'koneksi.php'; // Pastikan path ke koneksi.php benar

// Pastikan hanya admin yang bisa mengakses halaman ini
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login2.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $user_id = $_POST['id'];

    // 1. Ambil path file dari database
    $stmt_select = mysqli_prepare($conn, "SELECT file_path FROM register WHERE id = ? AND role = 'user'");
    if ($stmt_select) {
        mysqli_stmt_bind_param($stmt_select, "i", $user_id);
        mysqli_stmt_execute($stmt_select);
        mysqli_stmt_bind_result($stmt_select, $file_path);
        mysqli_stmt_fetch($stmt_select);
        mysqli_stmt_close($stmt_select);

        // 2. Hapus file fisik jika ada dan eksis
        if (!empty($file_path) && file_exists($file_path)) {
            if (unlink($file_path)) {
                // File fisik berhasil dihapus
                $_SESSION['success_message'] = "File fisik berhasil dihapus.";
            } else {
                $_SESSION['error_message'] = "Gagal menghapus file fisik.";
            }
        } else {
            $_SESSION['warning_message'] = "Tidak ada file terkait atau file tidak ditemukan di server.";
        }

        // 3. Update database: Set file_path menjadi NULL atau kosong
        $stmt_update = mysqli_prepare($conn, "UPDATE register SET file_path = NULL WHERE id = ?");
        if ($stmt_update) {
            mysqli_stmt_bind_param($stmt_update, "i", $user_id);
            if (mysqli_stmt_execute($stmt_update)) {
                $_SESSION['success_message'] = ($_SESSION['success_message'] ?? '') . " Data file di database berhasil dihapus.";
            } else {
                $_SESSION['error_message'] = ($_SESSION['error_message'] ?? '') . " Gagal menghapus data file dari database: " . mysqli_error($conn);
            }
            mysqli_stmt_close($stmt_update);
        } else {
            $_SESSION['error_message'] = ($_SESSION['error_message'] ?? '') . " Error preparing statement untuk update database: " . mysqli_error($conn);
        }

    } else {
        $_SESSION['error_message'] = "Error preparing statement untuk mengambil path file: " . mysqli_error($conn);
    }
} else {
    $_SESSION['error_message'] = "Permintaan tidak valid.";
}

// Redirect kembali ke halaman arsip
header('Location: arsip.php');
exit();
?>