<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    try {
     
        $stmt = $conn->prepare("SELECT id, username, password, is_verified, course, role FROM register WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                if ($user['is_verified'] == 1) {
                    $_SESSION['user'] = [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'role' => strtolower($user['role']),
                        'email' => $email
                    ];

              
                    error_log("Login sukses - User: ".$user['username'].", Role: ".$user['role']);

               
                    if ($_SESSION['user']['role'] === 'admin') {
                        header('Location: dashboard.php');
                        exit();
                    } else {
                        header('Location: index1.php');
                        exit();
                    }
                } else {
                    throw new Exception('Akun Anda belum terverifikasi. Silakan periksa email Anda.');
                }
            } else {
                throw new Exception('Email atau password salah.');
            }
        } else {
            throw new Exception('Email tidak ditemukan.');
        }
    } catch (Exception $e) {
        $_SESSION['login_error'] = $e->getMessage();
        header('Location: login2.php');
        exit();
    }
} else {
    header('Location: login2.php');
    exit();
}
?>
