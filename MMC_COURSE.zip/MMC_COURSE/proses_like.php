<?php
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $aksi = $_POST['aksi'];

    if ($aksi === 'like') {
        $query = "UPDATE komentar SET like_count = like_count + 1 WHERE id = $id";
    } elseif ($aksi === 'dislike') {
        $query = "UPDATE komentar SET dislike_count = dislike_count + 1 WHERE id = $id";
    }

    mysqli_query($conn, $query);
    header("Location: contact.php");
    exit();
}
?>
