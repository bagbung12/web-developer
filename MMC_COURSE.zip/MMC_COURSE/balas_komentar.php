<?php
session_start();
require 'koneksi.php';

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login2.php");
    exit();
}

$email = $_SESSION['email'];
$komentar = htmlspecialchars($_POST['komentar']);
$parent_id = intval($_POST['parent_id']);
$waktu = date("Y-m-d H:i:s");

$query = "INSERT INTO komentar (email, komentar, waktu, parent_id) VALUES ('$email', '$komentar', '$waktu', '$parent_id')";
mysqli_query($conn, $query);

header("Location: contact.php");
exit();
