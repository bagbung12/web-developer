<?php
require 'koneksi.php';
session_start();

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // Cari user dengan kode verifikasi yang cocok
    $stmt = $conn->prepare("SELECT * FROM register WHERE verification_code = ?");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Update status user menjadi verified
        $update = $conn->prepare("UPDATE register SET is_verified = 1 WHERE id = ?");
        $update->bind_param("i", $user['id']);
        if ($update->execute()) {
            $_SESSION['message'] = "Email berhasil diverifikasi! Anda sekarang dapat login.";
            header("Location: login2.php");
            exit();
        } else {
            $_SESSION['error'] = "Gagal memperbarui status verifikasi.";
            header("Location: register1.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Link verifikasi tidak valid atau sudah kadaluarsa.";
        header("Location: register1.php");
        exit();
    }
} else {
    $_SESSION['error'] = "Kode verifikasi tidak ditemukan.";
    header("Location: register1.php");
    exit();
}

?>
