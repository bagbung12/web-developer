<?php
session_start();
require 'koneksi.php'; // Pastikan file koneksi.php ada dan benar

// Redirect jika user belum login
if (!isset($_SESSION['user']['email'])) {
    header("Location: login2.php"); // Ganti ke login2.php jika itu halaman login Anda
    exit();
}

$email = isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : '';
$data = [
    'email' => '',
    'fullname' => '',
    'username' => ''
];

if (!empty($email)) {
    $email = mysqli_real_escape_string($conn, $email);
    // Pastikan kolom 'email' di tabel 'register' sesuai
    $query = mysqli_query($conn, "SELECT fullname, username, email FROM register WHERE email='$email'");
    $userData = mysqli_fetch_assoc($query);

    if ($userData) {
        $data = [
            'email' => $userData['email'],
            'fullname' => $userData['fullname'],
            'username' => $userData['username']
        ];
        // Tidak perlu $username untuk navbar karena navbar tidak digunakan
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Profil - MMC COURSE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="mmm.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url('download.jpeg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            color: #333;
            min-height: 100vh;
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            padding: 20px; /* Add some padding around the form on small screens */
            box-sizing: border-box; /* Pastikan padding tidak membuat body overflow */
        }

        /* Card Styling (similar to login/register/ganti password forms) */
        .card {
            background: rgba(255, 255, 255, 0.95); /* Semi-transparent white */
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); /* Stronger, softer shadow */
            padding: 30px; /* Increased padding */
            max-width: 420px; /* Consistent width with other forms */
            width: 100%;
            border: none; /* Remove default card border */
        }
        .card-title {
            font-weight: 700;
            color: #0d6efd; /* Consistent blue color */
            font-size: 2rem; /* Larger title */
            margin-bottom: 25px; /* Added margin for title */
            text-align: center;
        }
        .form-label {
            font-weight: 600;
            color: #444;
            margin-bottom: 8px; /* Space between label and input */
            display: block; /* Ensures label takes its own line */
        }
        
        /* Input Group with Icon Styling */
        .input-group-icon {
            position: relative;
            margin-bottom: 20px; /* Space between input fields */
        }
        .input-group-icon i.fas {
            position: absolute;
            left: 15px;
            top: 50%; /* Adjusted for vertical centering relative to parent */
            transform: translateY(-50%);
            color: #888;
            z-index: 2; /* Ensure icon is above input */
        }
        .input-group-icon .form-control {
            width: 100%;
            padding: 12px 15px 12px 45px; /* Padding for left icon, normal right padding */
            border-radius: 8px;
            border: 1px solid #ced4da;
            font-size: 1rem;
            box-sizing: border-box; /* Crucial: Include padding and border in the element's total width */
            outline: none; /* Remove default outline */
        }
        .input-group-icon .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }
        .input-group-icon .form-control::placeholder {
            color: #aaa; /* Adjust placeholder color */
        }
        
        /* Specific styling for readonly input (email) */
        .input-group-icon .form-control[readonly] {
            background-color: #e9ecef; /* Lighter background for readonly */
            opacity: 0.8;
            cursor: not-allowed;
        }
        /* End Input Group with Icon Styling */

        .btn-primary {
            background-color: #0d6efd; /* Primary blue button */
            border-color: #0d6efd;
            font-weight: 600;
            padding: 12px; /* Consistent padding */
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%; /* Make button full width */
            font-size: 1.1rem; /* Slightly larger button text */
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0b5ed7;
            transform: translateY(-2px);
        }

        .text-link {
            color: #0d6efd;
            text-decoration: none;
            transition: color 0.3s ease;
            display: block; /* Ensures link takes its own line */
            margin-top: 20px; /* Space above the link */
            text-align: center;
            font-size: 0.95rem; /* Consistent font size */
        }
        .text-link:hover {
            color: #0b5ed7;
        }

        @media (max-width: 767.98px) {
            .card-title {
                font-size: 1.8rem;
            }
            .card {
                padding: 20px;
                margin: 20px auto; /* Adjust margin for mobile */
            }
        }
    </style>
</head>
<body>

    <div class="card">
        <h4 class="card-title">Edit Profil</h4>
        <form method="POST" action="simpan_profil.php">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <div class="input-group-icon">
                    <i class="fas fa-envelope"></i> <input type="text" id="email" name="email" class="form-control" value="<?= htmlspecialchars($data['email']) ?>" readonly>
                </div>
            </div>
            <div class="mb-3">
                <label for="fullname" class="form-label">Full Name</label>
                <div class="input-group-icon">
                    <i class="fas fa-user"></i> <input type="text" id="fullname" name="fullname" class="form-control" value="<?= htmlspecialchars($data['fullname']) ?>">
                </div>
            </div>
            <div class="mb-4"> <label for="username" class="form-label">Username</label>
                <div class="input-group-icon">
                    <i class="fas fa-user-circle"></i> <input type="text" id="username" name="username" class="form-control" value="<?= htmlspecialchars($data['username']) ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100">Simpan Perubahan</button>
        </form>

        <div class="text-center mt-3">
            <a href="index1.php" class="text-decoration-none text-link">&larr; Kembali ke Beranda</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>