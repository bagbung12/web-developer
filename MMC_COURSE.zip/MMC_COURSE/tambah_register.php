<?php
require 'koneksi.php';

$fullname = $_POST['fullname'];
$username = $_POST['username'];
$course = $_POST['course'];
$email = $_POST['email'];
$password = $_POST['password'];
$role = $_POST['role'];
$tanggal = date('Y-m-d H:i:s');

$query = "INSERT INTO register (fullname, username, course, email, password, role, tanggal) 
          VALUES ('$fullname', '$username', '$course', '$email', '$password', '$role', '$tanggal')";

if (mysqli_query($conn, $query)) {
    header("Location: dashboard.php");
} else {
    echo "Gagal tambah data: " . mysqli_error($conn);
}
?>
