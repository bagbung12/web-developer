<?php
session_start();
// date_default_timezone_set('Asia/Jakarta'); // Ini tidak perlu di sini jika tidak ada operasi tanggal/waktu yang spesifik

$username = isset($_SESSION['user']['username']) ? htmlspecialchars($_SESSION['user']['username']) : 'PROFIL';
$current_page = basename($_SERVER['PHP_SELF']); // Ini akan menjadi 'index.php'
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MMC COURSE - HOME</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="icon" type="image/png" href="mmm.png">
    <style>
        body {
            font-family: 'Poppins', sans-serif; /* Menggunakan Poppins */
            background: url(download.jpeg) no-repeat center center fixed; /* Pastikan background fixed dan cover */
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
            min-height: 100vh; /* Agar footer selalu di bawah jika konten sedikit */
            display: flex;
            flex-direction: column;
        }

        main {
            flex: 1; /* Konten utama mengambil sisa ruang */
        }

        /* Navbar */
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08); /* Bayangan navbar lebih jelas */
            background-color: #ffffff; /* Pastikan navbar putih */
            z-index: 1030; /* Pastikan navbar di atas elemen lain */
        }
        .navbar-brand img {
            height: 35px; /* Sedikit lebih besar */
        }
        .navbar-nav .nav-link {
            font-weight: 500;
            color: #555;
            transition: color 0.3s ease;
            padding: 0.5rem 1rem; /* Padding nav-link */
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0d6efd; /* Warna biru Bootstrap */
        }
        .navbar-nav .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
            border: none;
        }

        /* Hero Section */
        .hero-section {
            text-align: center;
            padding: 120px 20px;
            background: rgba(0,0,0,0.6); /* Overlay gelap lebih kuat */
            color: #fff;
            border-radius: 10px;
            margin-top: 40px; /* Jarak dari navbar */
            animation: fadeIn 1s ease-out; /* Animasi fade in */
        }
        .hero-section h1 {
            font-size: 3.5rem; /* Lebih besar */
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.7); /* Bayangan teks lebih kuat */
            animation: slideInUp 1s ease-out; /* Animasi slide up */
        }
        .hero-section p {
            font-size: 1.3rem;
            margin-bottom: 40px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
            animation: slideInUp 1.2s ease-out;
        }
        .btn-cta {
            background-color: #FFC107; /* Kuning */
            border: none;
            padding: 14px 40px; /* Lebih besar */
            font-size: 1.2rem;
            border-radius: 50px;
            transition: all 0.3s ease;
            font-weight: 600;
            color: #333; /* Warna teks tombol */
        }
        .btn-cta:hover {
            background-color: #FFB300;
            transform: scale(1.05) translateY(-3px); /* Efek hover lebih dinamis */
            box-shadow: 0 8px 15px rgba(0,0,0,0.3);
            color: #333;
        }

        /* Course List */
        .course-list-section {
            background-color: rgba(255, 255, 255, 0.95); /* Latar belakang semi-transparan */
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-top: 50px; /* Jarak dari hero section */
            text-align: center;
        }
        .course-list-section h2 {
            font-size: 2.2rem;
            font-weight: 700;
            color: #0d6efd;
            margin-bottom: 40px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        }
        .course-list {
            list-style: none;
            padding: 0;
            display: flex;
            flex-wrap: wrap; /* Agar bisa wrap ke baris baru di layar kecil */
            justify-content: center;
            gap: 20px; /* Jarak antar item */
        }
        .course-list li {
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px 25px;
            font-size: 1.1rem;
            font-weight: 500;
            color: #555;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            min-width: 200px; /* Lebar minimum untuk item */
            justify-content: center;
        }
        .course-list li:hover {
            color: #0d6efd;
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .course-list li i {
            font-size: 1.3rem;
            margin-right: 10px;
            color: #28a745; /* Warna hijau untuk ikon check */
        }

        /* Footer */
        footer {
            background: #222; /* Warna footer lebih gelap */
            color: #e0e0e0;
            padding: 40px 20px;
            text-align: center;
            font-size: 0.95rem;
            margin-top: auto; /* Mendorong footer ke bawah */
        }
        footer a {
            color: #FFC107; /* Warna kuning untuk link */
            text-decoration: none;
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #ffe082;
        }
        footer .social-icons {
            margin-top: 15px;
        }
        footer .social-icons a {
            font-size: 1.5rem;
            margin: 0 10px;
        }

        /* Modal Promo */
        #promoModal .modal-content {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            background-color: #fff;
        }
        #promoModal .modal-header {
            background-color: #0d6efd; /* Warna header modal */
            color: white;
            border-bottom: none;
            padding: 1.5rem;
        }
        #promoModal .modal-title {
            font-weight: 700;
            font-size: 1.8rem;
        }
        #promoModal .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%); /* Membuat ikon close putih */
        }
        #promoModal .modal-body {
            padding: 0; /* Hapus padding default untuk iframe */
            background-color: #f8f9fa; /* Latar belakang body modal */
        }
        /* Iframe styling */
        #promoModal iframe {
            display: block; /* Hilangkan spasi di bawah iframe */
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideInUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2.5rem;
            }
            .hero-section p {
                font-size: 1rem;
            }
            .btn-cta {
                font-size: 1rem;
                padding: 10px 25px;
            }
            .course-list-section h2 {
                font-size: 1.8rem;
            }
            .course-list li {
                font-size: 1rem;
                padding: 10px 15px;
                min-width: unset; /* Hapus min-width di mobile */
            }
        }
    </style>
</head>
<body>
<div class="container-fluid px-0">
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm fixed-top"> <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                <img src="mmm.png" alt="MMC Logo" style="height: 40px; margin-right: 10px;">
                MMC COURSE
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav gap-2">
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'index.php' ? 'active' : '' ?>" href="index.php">HOME</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'blog1.php' ? 'active' : '' ?>" href="blog1.php">BLOG</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'service1.php' ? 'active' : '' ?>" href="service1.php">SERVICE</a></li>
                    <li class="nav-item"><a class="nav-link <?= $current_page == 'contact1.php' ? 'active' : '' ?>" href="contact1.php">CONTACT</a></li>
                     <li class="nav-item"><a class="nav-link <?= $current_page == 'login2.php' ? 'active' : '' ?>" href="login2.php">LOGIN</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div style="height: 70px;"></div> 

    <main class="container py-4">
        <?php if (isset($_SESSION['email'])): ?>
            <p style="display:none;"><strong><?php echo $_SESSION['email']; ?></strong>! Terima kasih telah login.</p>
        <?php endif; ?>

        <section class="hero-section">
            <h1>Tingkatkan Skillmu Bersama MMC COURSE!</h1>
            <p>Bergabunglah dengan ribuan siswa yang telah berhasil meraih impian mereka. Kami menyediakan kursus berkualitas tinggi dengan pengajar ahli.</p>
            <a href="login2.php" class="btn btn-cta">Daftar Sekarang</a>
        </section>

        <section class="course-list-section">
            <h2>MMC COURSE MENYEDIAKAN KURSUS:</h2>
            <ul class="course-list">
                <li><i class="fas fa-check-circle"></i> English</li>
                <li><i class="fas fa-check-circle"></i> Japanese</li>
                <li><i class="fas fa-check-circle"></i> Mandarin</li>
                <li><i class="fas fa-check-circle"></i> French</li>
                <li><i class="fas fa-check-circle"></i> Computer</li>
            </ul>
        </section>
    </main>

    <footer class="text-center">
        <div class="container">
            <p>&copy; <?= date("Y") ?> MMC Course. All rights reserved.</p>
            <div class="social-icons">
                <p>Ikuti kami:</p>
                <a href="https://www.instagram.com/mmc_course/" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </footer>
</div>

<div class="modal fade" id="promoModal" tabindex="-1" aria-labelledby="promoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="promoModalLabel">BACK TO SCHOOL PROMO!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div style="position: relative; width: 100%; height: 0; padding-top: 60%; overflow: hidden; border-radius: 8px;">
                    <iframe loading="lazy" style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; border: none;"
                      src="https://www.canva.com/design/DAGn3qZuUJo/9aXivrG7PRloHoTnDwzCPQ/watch?embed" allowfullscreen>
                    </iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Tampilkan modal promo saat halaman selesai dimuat
    window.addEventListener('DOMContentLoaded', () => {
        const promoModal = new bootstrap.Modal(document.getElementById('promoModal'));
        promoModal.show();
    });
</script>
</body>
</html>