<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'koneksi.php'; // koneksi ke database (kalau ingin simpan data klaim)
require 'vendor/autoload.php'; // pastikan sudah install PHPMailer via Composer

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Buat isi email
    $subject = "Voucer Terima Kasih dari MMC COURSE 🎁";
    $body = "
        <p>Terima kasih telah memberikan rating di Google Maps!</p>
        <p>Berikut adalah voucher Anda:</p>
        <h2 style='color:green;'>MMC-COURSE-VOUCHER10%-2025</h2>
        <p>T&C</p>
        <p>Tunjukkan kode ini saat datang ke MMC Course.</p>
        <hr>
        <p>MMC COURSE - Semangat Belajar!</p>
    ";

    $mail = new PHPMailer(true);

    try {
        // Konfigurasi SMTP Mailtrap/Gmail
        $mail->isSMTP();
        $mail->Host       = 'mmccourse.my.id'; // ganti dengan host SMTP-mu
        $mail->SMTPAuth   = true;
        $mail->Username   = 'mmccourse@mmccourse.my.id'; // username Mailtrap
        $mail->Password   = 'mmcoke123@'; // password Mailtrap
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('mmccourse@mmccourse.my.id', 'MMC_COURSE');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        header('Location: contact.php?status=voucher_sent');
    } catch (Exception $e) {
        echo "Gagal mengirim vocer: {$mail->ErrorInfo}";
    }
}
