<?php
define('SMTP_HOST', 'mmccourse.my.id');
define('SMTP_USER', 'mmccourse@mmccourse.my.id');
define('SMTP_PASS', 'mmcoke123@'); // ganti ini kalau kamu pakai password lain
define('SMTP_PORT', 587);
define('SENDER_EMAIL', 'mmccourse@mmccourse.my.id');
define('SENDER_NAME', 'MMC COURSE');
define('BASE_URL', 'https://mmccourse.my.id'); // domain kamu, bukan localhost
?>
